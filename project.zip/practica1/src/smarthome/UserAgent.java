package smarthome;

import jade.core.Agent;
import jade.core.AID;
import jade.core.behaviours.*;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import java.util.*;

public class UserAgent extends Agent {

    private UserState state = UserState.HOME;
    private Map<String, String> preferences = new HashMap<>();
    private List<String> notifications = new ArrayList<>();

    private enum UserState { HOME, AWAY, SLEEPING, VACATION }

    @Override
    protected void setup() {
        System.out.println("Пользователь " + getLocalName() + " запущен");

        loadPreferences();

        addBehaviour(new CommandHandlerBehaviour());
        addBehaviour(new NotificationBehaviour());
        addBehaviour(new ScenarioBehaviour());
        addBehaviour(new AutoModeBehaviour());

        addBehaviour(new OneShotBehaviour() {
            public void action() {
                greetUser();
            }
        });
    }

    private void loadPreferences() {
        preferences.put("morning-light", "70");
        preferences.put("evening-light", "50");
        preferences.put("sleep-temperature", "20");
        preferences.put("wakeup-time", "07:00");
        preferences.put("bedtime", "23:00");
        preferences.put("energy-saving", "true");
    }

    private class CommandHandlerBehaviour extends CyclicBehaviour {
        public void action() {
            ACLMessage msg = receive(MessageTemplate.MatchPerformative(ACLMessage.REQUEST));
            if (msg != null) {
                handleUserCommand(msg);
            } else {
                block();
            }
        }

        private void handleUserCommand(ACLMessage msg) {
            String command = msg.getContent();
            ACLMessage reply = msg.createReply();

            if (command.equals("get-status")) {
                reply.setPerformative(ACLMessage.INFORM);
                reply.setContent(getSystemStatus());
            } else if (command.startsWith("set-state:")) {
                String newState = command.substring(10);
                if (setUserState(newState)) {
                    reply.setPerformative(ACLMessage.CONFIRM);
                    reply.setContent("State changed to " + newState);
                    broadcastStateChange(newState);
                } else {
                    reply.setPerformative(ACLMessage.FAILURE);
                    reply.setContent("Invalid state");
                }
            } else if (command.startsWith("control-light:")) {
                String[] parts = command.split(":");
                if (parts.length >= 3) {
                    String light = parts[1];
                    String action = parts[2];
                    controlLight(light, action);
                    reply.setPerformative(ACLMessage.CONFIRM);
                    reply.setContent("Light control sent");
                }
            } else if (command.equals("get-notifications")) {
                reply.setPerformative(ACLMessage.INFORM);
                reply.setContent(String.join(";", notifications));
                notifications.clear();
            } else {
                reply.setPerformative(ACLMessage.NOT_UNDERSTOOD);
                reply.setContent("Unknown command");
            }

            send(reply);
        }
    }

    private class NotificationBehaviour extends CyclicBehaviour {
        private MessageTemplate template = MessageTemplate.MatchPerformative(ACLMessage.INFORM);

        public void action() {
            ACLMessage msg = myAgent.receive(template);
            if (msg != null) {
                handleNotification(msg);
            } else {
                block();
            }
        }

        private void handleNotification(ACLMessage msg) {
            String content = msg.getContent();
            String sender = msg.getSender().getLocalName();

            notifications.add(sender + ": " + content);
            System.out.println("📢 Уведомление от " + sender + ": " + content);

            if (content.startsWith("critical-energy:")) {
                handleCriticalEnergyAlert(content);
            } else if (content.startsWith("motion-detected:")) {
                handleMotionAlert(content);
            }
        }
    }

    private class ScenarioBehaviour extends TickerBehaviour {
        public ScenarioBehaviour() {
            super(UserAgent.this, 60000);
        }

        protected void onTick() {
            checkTimeBasedScenarios();

            if (state == UserState.AWAY) {
                executeAwayScenario();
            } else if (state == UserState.SLEEPING) {
                executeSleepScenario();
            }
        }

        private void checkTimeBasedScenarios() {
            Calendar now = Calendar.getInstance();
            int hour = now.get(Calendar.HOUR_OF_DAY);

            if (hour == 7 && state == UserState.HOME) {
                executeMorningScenario();
            } else if (hour == 19 && state == UserState.HOME) {
                executeEveningScenario();
            } else if (hour == 23 && state == UserState.HOME) {
                executeNightScenario();
            }
        }
    }

    private class AutoModeBehaviour extends TickerBehaviour {
        public AutoModeBehaviour() {
            super(UserAgent.this, 300000);
        }

        protected void onTick() {
            if (preferences.get("energy-saving").equals("true")) {
                optimizeEnergyUsage();
            }
        }
    }

    private void greetUser() {
        System.out.println("Добро пожаловать в Умный Дом!");
        System.out.println("Текущее состояние: " + state);
        System.out.println("Используйте команды для управления");
    }

    private String getSystemStatus() {
        return String.format("User: %s, State: %s, Notifications: %d",
                getLocalName(), state, notifications.size());
    }

    private boolean setUserState(String newStateStr) {
        try {
            UserState newState = UserState.valueOf(newStateStr.toUpperCase());
            state = newState;
            System.out.println("Состояние пользователя изменено на: " + state);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    private void broadcastStateChange(String newState) {
        ACLMessage broadcast = new ACLMessage(ACLMessage.INFORM);
        broadcast.setContent("user-state:" + newState);

        broadcast.addReceiver(new AID("EnergyManager", AID.ISLOCALNAME));
        broadcast.addReceiver(new AID("SecurityAgent", AID.ISLOCALNAME));

        send(broadcast);
    }

    private void controlLight(String lightName, String action) {
        ACLMessage command = new ACLMessage(ACLMessage.REQUEST);
        command.addReceiver(new AID(lightName, AID.ISLOCALNAME));

        if (action.equals("on")) {
            command.setContent("turn-on");
        } else if (action.equals("off")) {
            command.setContent("turn-off");
        } else if (action.startsWith("brightness=")) {
            command.setContent(action);
        }

        send(command);
    }

    private void handleCriticalEnergyAlert(String content) {
        String[] parts = content.split(":");
        double consumption = Double.parseDouble(parts[1].replace("W", ""));

        System.out.println("⚠️ КРИТИЧЕСКОЕ ПОТРЕБЛЕНИЕ ЭНЕРГИИ: " + consumption + "W");

        ACLMessage emergency = new ACLMessage(ACLMessage.REQUEST);
        emergency.addReceiver(new AID("EnergyManager", AID.ISLOCALNAME));
        emergency.setContent("emergency-mode");
        send(emergency);
    }

    private void handleMotionAlert(String content) {
        String location = content.split(":")[1];

        if (state == UserState.AWAY || state == UserState.VACATION) {
            System.out.println("🚨 ОБНАРУЖЕНО ДВИЖЕНИЕ В ВАШЕ ОТСУТСТВИЕ: " + location);

            ACLMessage security = new ACLMessage(ACLMessage.REQUEST);
            security.addReceiver(new AID("SecurityAgent", AID.ISLOCALNAME));
            security.setContent("intrusion-alert:" + location);
            send(security);
        }
    }

    private void executeMorningScenario() {
        System.out.println("Запуск утреннего сценария");

        controlLight("Light-Bedroom", "brightness=70");
        controlLight("Light-LivingRoom", "turn-on");

        ACLMessage thermo = new ACLMessage(ACLMessage.REQUEST);
        thermo.addReceiver(new AID("Thermo-LivingRoom", AID.ISLOCALNAME));
        thermo.setContent("set-temperature:22");
        send(thermo);
    }

    private void executeEveningScenario() {
        System.out.println("Запуск вечернего сценария");

        controlLight("Light-LivingRoom", "brightness=50");
        controlLight("Light-Bedroom", "brightness=30");

        ACLMessage media = new ACLMessage(ACLMessage.REQUEST);
        media.addReceiver(new AID("Media-LivingRoom", AID.ISLOCALNAME));
        media.setContent("play-relaxing-music");
        send(media);
    }

    private void executeNightScenario() {
        System.out.println("Запуск ночного сценария");

        controlLight("Light-LivingRoom", "turn-off");
        controlLight("Light-Bedroom", "brightness=10");

        setUserState("SLEEPING");
    }

    private void executeAwayScenario() {
        ACLMessage security = new ACLMessage(ACLMessage.REQUEST);
        security.addReceiver(new AID("SecurityAgent", AID.ISLOCALNAME));
        security.setContent("activate-away-mode");
        send(security);

        ACLMessage energy = new ACLMessage(ACLMessage.REQUEST);
        energy.addReceiver(new AID("EnergyManager", AID.ISLOCALNAME));
        energy.setContent("power-save-mode");
        send(energy);
    }

    private void executeSleepScenario() {
        controlLight("Light-Bedroom", "brightness=5");

        ACLMessage thermo = new ACLMessage(ACLMessage.REQUEST);
        thermo.addReceiver(new AID("Thermo-Bedroom", AID.ISLOCALNAME));
        thermo.setContent("set-temperature:20");
        send(thermo);
    }

    private void optimizeEnergyUsage() {
        ACLMessage optimize = new ACLMessage(ACLMessage.REQUEST);
        optimize.addReceiver(new AID("EnergyManager", AID.ISLOCALNAME));
        optimize.setContent("optimize-energy");
        send(optimize);
    }

    @Override
    protected void takeDown() {
        System.out.println("Пользователь завершает работу");
    }
}
