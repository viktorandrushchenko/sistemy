package smarthome;

import jade.core.Agent;
import jade.core.AID;
import jade.core.behaviours.*;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.*;
import jade.domain.FIPAException;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import java.util.*;

public class LightAgent extends Agent {

    private enum LightState { ON, OFF, DIM, AUTO, EMERGENCY }
    private enum LightMode { MANUAL, SCHEDULE, MOTION, DAYLIGHT }

    private LightState currentState = LightState.OFF;
    private LightMode currentMode = LightMode.MANUAL;
    private int brightness = 0;
    private String location;
    private List<String> controlledLights = new ArrayList<>();

    private boolean motionDetected = false;
    private boolean daylightAvailable = false;
    private boolean userPresent = false;

    private double powerConsumption = 0.0;
    private double maxPower = 60.0;
    private long lastUpdateTime;

    private Map<String, LightSchedule> schedule = new HashMap<>();
    private List<String> history = new ArrayList<>();

    @Override
    protected void setup() {
        Object[] args = getArguments();
        if (args != null && args.length > 0) {
            if (args[0] instanceof String[]) {
                String[] lights = (String[]) args[0];
                controlledLights.addAll(Arrays.asList(lights));
            }
            if (args.length > 1 && args[1] instanceof String) {
                location = (String) args[1];
            }
        }

        if (location == null) {
            location = "unknown";
        }

        registerWithDF();

        addBehaviour(new LightControlBehaviour());
        addBehaviour(new SensorMonitoringBehaviour());
        addBehaviour(new EnergySavingBehaviour());
        addBehaviour(new ScheduleBehaviour());

        System.out.println(getLocalName() + " запущен в комнате: " + location);

        addBehaviour(new OneShotBehaviour() {
            public void action() {
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {}

                ACLMessage discovery = new ACLMessage(ACLMessage.REQUEST);
                discovery.addReceiver(new AID("EnergyManager", AID.ISLOCALNAME));
                discovery.setContent("register");
                discovery.setConversationId("light-registration");
                send(discovery);
            }
        });
    }

    private void registerWithDF() {
        try {
            DFAgentDescription dfd = new DFAgentDescription();
            dfd.setName(getAID());

            ServiceDescription sd = new ServiceDescription();
            sd.setType("light");
            sd.setName("smart-light");
            sd.addProperties(new Property("location", location));
            sd.addProperties(new Property("state", currentState.toString()));
            sd.addProperties(new Property("brightness", String.valueOf(brightness)));

            dfd.addServices(sd);
            DFService.register(this, dfd);
        } catch (FIPAException e) {
            e.printStackTrace();
        }
    }

    private void updateDF() {
        try {
            DFAgentDescription dfd = new DFAgentDescription();
            dfd.setName(getAID());

            ServiceDescription sd = new ServiceDescription();
            sd.setType("light");
            sd.setName("smart-light");
            sd.addProperties(new Property("location", location));
            sd.addProperties(new Property("state", currentState.toString()));
            sd.addProperties(new Property("brightness", String.valueOf(brightness)));
            sd.addProperties(new Property("power", String.valueOf(powerConsumption)));

            DFService.modify(this, dfd);
        } catch (FIPAException e) {
            e.printStackTrace();
        }
    }

    private class LightControlBehaviour extends CyclicBehaviour {
        private MessageTemplate requestTemplate = MessageTemplate.MatchPerformative(ACLMessage.REQUEST);
        private MessageTemplate cfpTemplate = MessageTemplate.and(
                MessageTemplate.MatchPerformative(ACLMessage.CFP),
                MessageTemplate.MatchProtocol("fipa-contract-net")
        );

        public void action() {
            ACLMessage request = myAgent.receive(requestTemplate);
            if (request != null) {
                handleLightRequest(request);
                return;
            }

            ACLMessage cfp = myAgent.receive(cfpTemplate);
            if (cfp != null) {
                handleEnergyCFP(cfp);
                return;
            }

            block();
        }

        private void handleLightRequest(ACLMessage request) {
            String content = request.getContent();
            ACLMessage reply = request.createReply();

            if (content.equals("turn-on")) {
                turnOn();
                reply.setPerformative(ACLMessage.CONFIRM);
                reply.setContent("Light turned ON");
            } else if (content.equals("turn-off")) {
                turnOff();
                reply.setPerformative(ACLMessage.CONFIRM);
                reply.setContent("Light turned OFF");
            } else if (content.startsWith("brightness=")) {
                try {
                    int newBrightness = Integer.parseInt(content.substring(11));
                    setBrightness(newBrightness);
                    reply.setPerformative(ACLMessage.CONFIRM);
                    reply.setContent("Brightness set to " + newBrightness);
                } catch (NumberFormatException e) {
                    reply.setPerformative(ACLMessage.FAILURE);
                    reply.setContent("Invalid brightness value");
                }
            } else if (content.equals("get-status")) {
                reply.setPerformative(ACLMessage.INFORM);
                reply.setContent(getStatus());
            } else if (content.startsWith("mode=")) {
                String mode = content.substring(5);
                if (setMode(mode)) {
                    reply.setPerformative(ACLMessage.CONFIRM);
                    reply.setContent("Mode set to " + mode);
                } else {
                    reply.setPerformative(ACLMessage.FAILURE);
                    reply.setContent("Invalid mode");
                }
            } else {
                reply.setPerformative(ACLMessage.NOT_UNDERSTOOD);
                reply.setContent("Unknown command");
            }

            send(reply);
        }

        private void handleEnergyCFP(ACLMessage cfp) {
            String content = cfp.getContent();

            if (content.startsWith("reduce-power:")) {
                try {
                    double reductionPercent = Double.parseDouble(content.substring(13));
                    handlePowerReductionRequest(cfp, reductionPercent);
                } catch (NumberFormatException e) {
                    sendRefuse(cfp, "Invalid reduction percentage");
                }
            }
        }

        private void handlePowerReductionRequest(ACLMessage cfp, double reductionPercent) {
            double currentPower = calculateCurrentPower();
            double targetPower = currentPower * (1 - reductionPercent / 100);

            if (targetPower < maxPower * 0.1) {
                sendRefuse(cfp, "Cannot reduce below minimum level");
                return;
            }

            int newBrightness = calculateOptimalBrightness(targetPower);
            double savedPower = currentPower - calculatePowerForBrightness(newBrightness);

            ACLMessage propose = cfp.createReply();
            propose.setPerformative(ACLMessage.PROPOSE);
            propose.setContent(String.valueOf(savedPower));
            propose.setConversationId(cfp.getConversationId());
            send(propose);

            addBehaviour(new ContractNetResponderBehaviour(cfp, newBrightness, savedPower));
        }

        private void sendRefuse(ACLMessage cfp, String reason) {
            ACLMessage refuse = cfp.createReply();
            refuse.setPerformative(ACLMessage.REFUSE);
            refuse.setContent(reason);
            send(refuse);
        }
    }

    private class ContractNetResponderBehaviour extends Behaviour {
        private ACLMessage originalCFP;
        private int proposedBrightness;
        private double savedPower;
        private boolean finished = false;

        public ContractNetResponderBehaviour(ACLMessage cfp, int brightness, double saved) {
            originalCFP = cfp;
            proposedBrightness = brightness;
            savedPower = saved;
        }

        public void action() {
            MessageTemplate template = MessageTemplate.and(
                    MessageTemplate.MatchConversationId(originalCFP.getConversationId()),
                    MessageTemplate.or(
                            MessageTemplate.MatchPerformative(ACLMessage.ACCEPT_PROPOSAL),
                            MessageTemplate.MatchPerformative(ACLMessage.REJECT_PROPOSAL)
                    )
            );

            ACLMessage response = myAgent.receive(template);
            if (response != null) {
                if (response.getPerformative() == ACLMessage.ACCEPT_PROPOSAL) {
                    setBrightness(proposedBrightness);

                    ACLMessage inform = response.createReply();
                    inform.setPerformative(ACLMessage.INFORM);
                    inform.setContent("Power reduced by " + savedPower + "W");
                    send(inform);

                    System.out.println(getLocalName() + ": принято предложение по экономии энергии");
                }
                finished = true;
            } else {
                block();
            }
        }

        public boolean done() {
            return finished;
        }
    }

    private class SensorMonitoringBehaviour extends TickerBehaviour {
        public SensorMonitoringBehaviour() {
            super(LightAgent.this, 3000);
        }

        protected void onTick() {
            checkSensors();

            if (currentMode == LightMode.MOTION) {
                if (motionDetected && !userPresent) {
                    turnOn();
                    userPresent = true;
                } else if (!motionDetected && userPresent) {
                    addBehaviour(new DelayedTurnOffBehaviour());
                }
            }

            if (currentMode == LightMode.DAYLIGHT) {
                if (daylightAvailable && brightness > 50) {
                    setBrightness(50);
                } else if (!daylightAvailable && brightness < 80) {
                    setBrightness(80);
                }
            }
        }

        private void checkSensors() {
            Random rand = new Random();
            motionDetected = rand.nextDouble() < 0.3;
            daylightAvailable = isDayTime();

            if (motionDetected) {
                ACLMessage alert = new ACLMessage(ACLMessage.INFORM);
                alert.addReceiver(new AID("SecurityAgent", AID.ISLOCALNAME));
                alert.setContent("motion-detected:" + location);
                alert.setConversationId("sensor-alert");
                send(alert);
            }
        }

        private boolean isDayTime() {
            Calendar cal = Calendar.getInstance();
            int hour = cal.get(Calendar.HOUR_OF_DAY);
            return hour >= 6 && hour <= 20;
        }
    }

    private class DelayedTurnOffBehaviour extends Behaviour {
        private long startTime;
        private static final long DELAY = 30000;

        public DelayedTurnOffBehaviour() {
            startTime = System.currentTimeMillis();
        }

        public void action() {
            long currentTime = System.currentTimeMillis();
            if (currentTime - startTime >= DELAY) {
                if (!motionDetected) {
                    turnOff();
                    userPresent = false;
                }
                removeBehaviour(this);
            }
        }

        public boolean done() {
            return false;
        }
    }

    private class EnergySavingBehaviour extends TickerBehaviour {
        public EnergySavingBehaviour() {
            super(LightAgent.this, 10000);
        }

        protected void onTick() {
            updatePowerConsumption();

            if (powerConsumption > maxPower * 0.8) {
                reduceBrightness(20);

                ACLMessage warning = new ACLMessage(ACLMessage.INFORM);
                warning.addReceiver(new AID("EnergyManager", AID.ISLOCALNAME));
                warning.setContent("high-consumption:" + getLocalName() + ":" + powerConsumption);
                send(warning);
            }
        }
    }

    private class ScheduleBehaviour extends TickerBehaviour {
        public ScheduleBehaviour() {
            super(LightAgent.this, 60000);
        }

        protected void onTick() {
            if (currentMode == LightMode.SCHEDULE) {
                checkSchedule();
            }
        }

        private void checkSchedule() {
            Calendar now = Calendar.getInstance();
            String timeKey = String.format("%02d:%02d", now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE));

            if (schedule.containsKey(timeKey)) {
                LightSchedule sched = schedule.get(timeKey);
                if (sched.action.equals("on")) {
                    turnOn();
                    setBrightness(sched.brightness);
                } else if (sched.action.equals("off")) {
                    turnOff();
                }
            }
        }
    }

    private void turnOn() {
        if (currentState != LightState.ON) {
            currentState = LightState.ON;
            if (brightness == 0) brightness = 80;
            System.out.println(getLocalName() + ": свет ВКЛЮЧЕН");
            history.add("Turned ON at " + new Date());
            updateDF();
        }
    }

    private void turnOff() {
        if (currentState != LightState.OFF) {
            currentState = LightState.OFF;
            brightness = 0;
            System.out.println(getLocalName() + ": свет ВЫКЛЮЧЕН");
            history.add("Turned OFF at " + new Date());
            updateDF();
        }
    }

    private void setBrightness(int value) {
        if (value < 0) value = 0;
        if (value > 100) value = 100;

        brightness = value;
        if (brightness == 0) {
            currentState = LightState.OFF;
        } else if (brightness < 50) {
            currentState = LightState.DIM;
        } else {
            currentState = LightState.ON;
        }

        System.out.println(getLocalName() + ": яркость установлена на " + brightness + "%");
        history.add("Brightness set to " + brightness + "% at " + new Date());
        updateDF();
    }

    private boolean setMode(String modeStr) {
        try {
            LightMode mode = LightMode.valueOf(modeStr.toUpperCase());
            currentMode = mode;
            System.out.println(getLocalName() + ": режим изменен на " + mode);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    private String getStatus() {
        return String.format("State: %s, Brightness: %d%%, Mode: %s, Power: %.1fW, Location: %s",
                currentState, brightness, currentMode, powerConsumption, location);
    }

    private void reduceBrightness(int percent) {
        int newBrightness = brightness * (100 - percent) / 100;
        if (newBrightness < 10) newBrightness = 10;
        setBrightness(newBrightness);
    }

    private void updatePowerConsumption() {
        powerConsumption = maxPower * brightness / 100.0;
        lastUpdateTime = System.currentTimeMillis();
    }

    private double calculateCurrentPower() {
        return maxPower * brightness / 100.0;
    }

    private double calculatePowerForBrightness(int brightness) {
        return maxPower * brightness / 100.0;
    }

    private int calculateOptimalBrightness(double targetPower) {
        int targetBrightness = (int)((targetPower / maxPower) * 100);
        if (targetBrightness < 10) targetBrightness = 10;
        if (targetBrightness > 90) targetBrightness = 90;
        return targetBrightness;
    }

    @Override
    protected void takeDown() {
        try {
            DFService.deregister(this);
        } catch (FIPAException e) {
            e.printStackTrace();
        }
        System.out.println(getLocalName() + " завершает работу");
    }

    static class LightSchedule {
        String time;
        String action;
        int brightness;

        LightSchedule(String time, String action, int brightness) {
            this.time = time;
            this.action = action;
            this.brightness = brightness;
        }
    }

    static class ColorRGB {
        int r, g, b;

        ColorRGB(int r, int g, int b) {
            this.r = r;
            this.g = g;
            this.b = b;
        }
    }
}