package smarthome;

import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;

public class SmartHomeMain {
    public static void main(String[] args) {
        Runtime rt = Runtime.instance();
        Profile profile = new ProfileImpl();
        profile.setParameter(Profile.MAIN_HOST, "localhost");
        profile.setParameter(Profile.MAIN_PORT, "1099");
        profile.setParameter(Profile.GUI, "true");

        AgentContainer mainContainer = rt.createMainContainer(profile);

        try {
            System.out.println("🏠 Запуск Умного Дома...");

            Thread.sleep(2000);

            String[] livingRoomLights = {"MainLight", "AccentLight", "ReadingLight"};
            String[] bedroomLights = {"BedsideLight", "CeilingLight"};

            AgentController lightLiving = mainContainer.createNewAgent(
                    "Light-LivingRoom", "smarthome.LightAgent",
                    new Object[]{livingRoomLights, "livingroom"});

            AgentController lightBedroom = mainContainer.createNewAgent(
                    "Light-Bedroom", "smarthome.LightAgent",
                    new Object[]{bedroomLights, "bedroom"});

            AgentController energyManager = mainContainer.createNewAgent(
                    "EnergyManager", "smarthome.EnergyManager", null);

            AgentController user = mainContainer.createNewAgent(
                    "User", "smarthome.UserAgent", null);



            lightLiving.start();
            lightBedroom.start();
            energyManager.start();
            user.start();

            System.out.println("Система Умного Дома запущена!");
            System.out.println("Доступные агенты:");
            System.out.println("  - Light-LivingRoom (освещение гостиной)");
            System.out.println("  - Light-Bedroom (освещение спальни)");
            System.out.println("  - EnergyManager (управление энергией)");
            System.out.println("  - User (пользователь)");

            Thread.sleep(5000);

            System.out.println("\n Тестирование системы...");
            testSystem(mainContainer);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void testSystem(AgentContainer container) throws Exception {
        Thread.sleep(3000);

        System.out.println("1. Включаем свет в гостиной...");
        AgentController tester = container.createNewAgent(
                "Tester", "jade.tools.DummyAgent.DummyAgent", null);
        tester.start();

        Thread.sleep(5000);

        System.out.println("2. Запускаем режим экономии энергии...");
        AgentController user = container.getAgent("User");

        Thread.sleep(10000);

        System.out.println("3. Тестируем Contract Net...");

        Thread.sleep(15000);

        System.out.println("Тестирование завершено!");
    }
}