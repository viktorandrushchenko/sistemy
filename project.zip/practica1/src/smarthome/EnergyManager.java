package smarthome;

import jade.core.Agent;
import jade.core.AID;
import jade.core.behaviours.*;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.*;
import jade.domain.FIPAException;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.proto.ContractNetInitiator;
import java.util.*;

public class EnergyManager extends Agent {

    private Map<String, DeviceInfo> devices = new HashMap<>();
    private double totalConsumption = 0.0;
    private double powerLimit = 1000.0;
    private double currentTariff = 5.0;
    private EnergyMode mode = EnergyMode.NORMAL;

    private enum EnergyMode { NORMAL, SAVING, CRITICAL, OVERLOAD }

    @Override
    protected void setup() {
        System.out.println(getLocalName() + " запущен");

        registerWithDF();

        addBehaviour(new DeviceMonitoringBehaviour());
        addBehaviour(new PowerManagementBehaviour());
        addBehaviour(new ContractNetInitiatorBehaviour());
        addBehaviour(new AlertBehaviour());

        addBehaviour(new OneShotBehaviour() {
            public void action() {
                try {
                    Thread.sleep(3000);
                    discoverDevices();
                } catch (InterruptedException e) {}
            }
        });
    }

    private void registerWithDF() {
        try {
            DFAgentDescription dfd = new DFAgentDescription();
            dfd.setName(getAID());

            ServiceDescription sd = new ServiceDescription();
            sd.setType("energy-manager");
            sd.setName("energy-management");

            dfd.addServices(sd);
            DFService.register(this, dfd);
        } catch (FIPAException e) {
            e.printStackTrace();
        }
    }

    private class DeviceMonitoringBehaviour extends CyclicBehaviour {
        private MessageTemplate template = MessageTemplate.or(
                MessageTemplate.MatchPerformative(ACLMessage.INFORM),
                MessageTemplate.MatchPerformative(ACLMessage.REQUEST)
        );

        public void action() {
            ACLMessage msg = myAgent.receive(template);
            if (msg != null) {
                handleMessage(msg);
            } else {
                block();
            }
        }

        private void handleMessage(ACLMessage msg) {
            String content = msg.getContent();
            String sender = msg.getSender().getLocalName();

            if (msg.getPerformative() == ACLMessage.REQUEST && content.equals("register")) {
                handleDeviceRegistration(sender, msg);
            } else if (content.startsWith("high-consumption:")) {
                handleHighConsumptionAlert(sender, content);
            } else if (content.startsWith("consumption:")) {
                updateDeviceConsumption(sender, content);
            } else if (content.startsWith("device-status:")) {
                updateDeviceStatus(sender, content);
            }
        }

        private void handleDeviceRegistration(String deviceName, ACLMessage msg) {
            if (!devices.containsKey(deviceName)) {
                DeviceInfo info = new DeviceInfo(deviceName);
                devices.put(deviceName, info);

                ACLMessage reply = msg.createReply();
                reply.setPerformative(ACLMessage.CONFIRM);
                reply.setContent("registered");
                send(reply);

                System.out.println("Зарегистрировано устройство: " + deviceName);
            }
        }

        private void handleHighConsumptionAlert(String deviceName, String content) {
            String[] parts = content.split(":");
            if (parts.length >= 3) {
                double consumption = Double.parseDouble(parts[2]);

                DeviceInfo info = devices.get(deviceName);
                if (info != null) {
                    info.lastConsumption = consumption;
                    info.alertCount++;

                    if (mode != EnergyMode.CRITICAL) {
                        mode = EnergyMode.SAVING;
                        System.out.println("Переход в режим экономии из-за устройства " + deviceName);
                        initiatePowerReduction(20);
                    }
                }
            }
        }

        private void updateDeviceConsumption(String deviceName, String content) {
            String[] parts = content.split(":");
            if (parts.length >= 2) {
                try {
                    double consumption = Double.parseDouble(parts[1]);

                    DeviceInfo info = devices.get(deviceName);
                    if (info != null) {
                        info.lastConsumption = consumption;
                        info.lastUpdate = System.currentTimeMillis();
                        updateTotalConsumption();
                    }
                } catch (NumberFormatException e) {}
            }
        }

        private void updateDeviceStatus(String deviceName, String content) {
            DeviceInfo info = devices.get(deviceName);
            if (info != null) {
                info.status = content.substring(content.indexOf(':') + 1);
            }
        }
    }

    private class PowerManagementBehaviour extends TickerBehaviour {
        public PowerManagementBehaviour() {
            super(EnergyManager.this, 15000);
        }

        protected void onTick() {
            checkPowerConsumption();

            if (totalConsumption > powerLimit * 0.9) {
                if (mode != EnergyMode.CRITICAL) {
                    mode = EnergyMode.CRITICAL;
                    System.out.println("КРИТИЧЕСКИЙ РЕЖИМ! Потребление: " + totalConsumption + "W");
                    initiateEmergencyReduction();
                }
            } else if (totalConsumption > powerLimit * 0.7) {
                if (mode == EnergyMode.NORMAL) {
                    mode = EnergyMode.SAVING;
                    System.out.println("Режим экономии. Потребление: " + totalConsumption + "W");
                    initiatePowerReduction(15);
                }
            } else if (totalConsumption < powerLimit * 0.5) {
                if (mode != EnergyMode.NORMAL) {
                    mode = EnergyMode.NORMAL;
                    System.out.println("Нормальный режим. Потребление: " + totalConsumption + "W");
                }
            }

            removeInactiveDevices();
            broadcastConsumptionUpdate();
        }

        private void checkPowerConsumption() {
            double newTotal = 0.0;
            for (DeviceInfo info : devices.values()) {
                newTotal += info.lastConsumption;
            }
            totalConsumption = newTotal;
        }

        private void removeInactiveDevices() {
            long currentTime = System.currentTimeMillis();
            Iterator<Map.Entry<String, DeviceInfo>> it = devices.entrySet().iterator();

            while (it.hasNext()) {
                Map.Entry<String, DeviceInfo> entry = it.next();
                if (currentTime - entry.getValue().lastUpdate > 300000) {
                    System.out.println("Удалено неактивное устройство: " + entry.getKey());
                    it.remove();
                }
            }
        }

        private void broadcastConsumptionUpdate() {
            ACLMessage update = new ACLMessage(ACLMessage.INFORM);
            update.setContent("total-consumption:" + totalConsumption);

            for (String deviceName : devices.keySet()) {
                update.addReceiver(new AID(deviceName, AID.ISLOCALNAME));
            }

            send(update);
        }
    }

    private class ContractNetInitiatorBehaviour extends OneShotBehaviour {
        public void action() {
            initiatePowerReduction(10);
        }
    }

    private void initiatePowerReduction(double percent) {
        System.out.println("Инициирую сокращение мощности на " + percent + "%");

        ACLMessage cfp = new ACLMessage(ACLMessage.CFP);
        cfp.setProtocol("fipa-contract-net");
        cfp.setContent("reduce-power:" + percent);
        cfp.setReplyByDate(new Date(System.currentTimeMillis() + 10000));

        for (String deviceName : devices.keySet()) {
            if (!deviceName.equals(getLocalName())) {
                cfp.addReceiver(new AID(deviceName, AID.ISLOCALNAME));
            }
        }

        addBehaviour(new PowerReductionContractNet(cfp, percent));
    }

    private void initiateEmergencyReduction() {
        System.out.println("ЭКСТРЕННОЕ сокращение мощности!");

        ACLMessage emergency = new ACLMessage(ACLMessage.REQUEST);
        emergency.setContent("emergency-power-reduction");

        for (String deviceName : devices.keySet()) {
            DeviceInfo info = devices.get(deviceName);
            if (info.priority > 3) {
                emergency.addReceiver(new AID(deviceName, AID.ISLOCALNAME));
            }
        }

        send(emergency);

        initiatePowerReduction(40);
    }

    private class PowerReductionContractNet extends ContractNetInitiator {
        private double targetReduction;

        public PowerReductionContractNet(ACLMessage cfp, double reduction) {
            super(EnergyManager.this, cfp);
            targetReduction = reduction;
        }

        protected Vector prepareCfps(ACLMessage cfp) {
            System.out.println("Отправка CFP устройствам");
            return super.prepareCfps(cfp);
        }

        protected void handlePropose(ACLMessage propose, Vector acceptances) {
            String device = propose.getSender().getLocalName();
            double savedPower = Double.parseDouble(propose.getContent());
            System.out.println("Предложение от " + device + ": сэкономит " + savedPower + "W");
        }

        protected void handleRefuse(ACLMessage refuse) {
            System.out.println("Отказ от " + refuse.getSender().getLocalName() + ": " + refuse.getContent());
        }

        protected void handleAllResponses(Vector responses, Vector acceptances) {
            Map<String, Double> proposals = new HashMap<>();
            double totalSaved = 0.0;

            for (Object obj : responses) {
                ACLMessage msg = (ACLMessage) obj;
                if (msg.getPerformative() == ACLMessage.PROPOSE) {
                    try {
                        double saved = Double.parseDouble(msg.getContent());
                        proposals.put(msg.getSender().getLocalName(), saved);
                        totalSaved += saved;
                    } catch (NumberFormatException e) {}
                }
            }

            double requiredReduction = totalConsumption * targetReduction / 100.0;

            if (totalSaved >= requiredReduction * 0.8) {
                selectBestProposals(proposals, requiredReduction, acceptances);
                System.out.println("Достаточно предложений. Требуется: " + requiredReduction + "W, получено: " + totalSaved + "W");
            } else {
                System.out.println("Недостаточно предложений. Требуется: " + requiredReduction + "W, получено: " + totalSaved + "W");
                initiateEmergencyReduction();
            }
        }

        private void selectBestProposals(Map<String, Double> proposals, double required, Vector acceptances) {
            List<Map.Entry<String, Double>> sorted = new ArrayList<>(proposals.entrySet());
            sorted.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));

            double accumulated = 0.0;
            for (Map.Entry<String, Double> entry : sorted) {
                if (accumulated < required) {
                    ACLMessage accept = new ACLMessage(ACLMessage.ACCEPT_PROPOSAL);
                    accept.addReceiver(new AID(entry.getKey(), AID.ISLOCALNAME));
                    accept.setContent("accepted");
                    acceptances.add(accept);
                    accumulated += entry.getValue();
                } else {
                    ACLMessage reject = new ACLMessage(ACLMessage.REJECT_PROPOSAL);
                    reject.addReceiver(new AID(entry.getKey(), AID.ISLOCALNAME));
                    reject.setContent("rejected");
                    send(reject);
                }
            }
        }

        protected void handleInform(ACLMessage inform) {
            System.out.println("Успешное сокращение от " + inform.getSender().getLocalName());
        }

        protected void handleFailure(ACLMessage failure) {
            System.out.println("Ошибка сокращения от " + failure.getSender().getLocalName());
        }
    }

    private class AlertBehaviour extends TickerBehaviour {
        public AlertBehaviour() {
            super(EnergyManager.this, 30000);
        }

        protected void onTick() {
            if (mode == EnergyMode.CRITICAL) {
                sendCriticalAlert();
            }

            if (totalConsumption > powerLimit * 0.8) {
                sendHighConsumptionAlert();
            }

            logConsumption();
        }

        private void sendCriticalAlert() {
            ACLMessage alert = new ACLMessage(ACLMessage.INFORM);
            alert.addReceiver(new AID("UserAgent", AID.ISLOCALNAME));
            alert.setContent("critical-energy:" + totalConsumption + "W");
            send(alert);
        }

        private void sendHighConsumptionAlert() {
            ACLMessage alert = new ACLMessage(ACLMessage.INFORM);
            alert.addReceiver(new AID("UserAgent", AID.ISLOCALNAME));
            alert.setContent("high-energy-consumption:" + totalConsumption + "W");
            send(alert);
        }

        private void logConsumption() {
            System.out.println("=== ПОТРЕБЛЕНИЕ ЭНЕРГИИ ===");
            System.out.println("Всего: " + totalConsumption + "W");
            System.out.println("Лимит: " + powerLimit + "W");
            System.out.println("Режим: " + mode);
            System.out.println("Устройств: " + devices.size());
            System.out.println("========================");
        }
    }

    private void discoverDevices() {
        try {
            DFAgentDescription template = new DFAgentDescription();
            ServiceDescription sd = new ServiceDescription();
            sd.setType("light");
            template.addServices(sd);

            DFAgentDescription[] results = DFService.search(this, template);

            for (DFAgentDescription result : results) {
                String deviceName = result.getName().getLocalName();
                if (!devices.containsKey(deviceName)) {
                    DeviceInfo info = new DeviceInfo(deviceName);
                    devices.put(deviceName, info);
                    System.out.println("Обнаружено устройство через DF: " + deviceName);
                }
            }

        } catch (FIPAException e) {
            e.printStackTrace();
        }
    }

    private void updateTotalConsumption() {
        totalConsumption = devices.values().stream()
                .mapToDouble(info -> info.lastConsumption)
                .sum();
    }

    @Override
    protected void takeDown() {
        try {
            DFService.deregister(this);
        } catch (FIPAException e) {
            e.printStackTrace();
        }
        System.out.println(getLocalName() + " завершает работу");
    }

    static class DeviceInfo {
        String name;
        double lastConsumption = 0.0;
        long lastUpdate;
        String status = "unknown";
        int priority = 5;
        int alertCount = 0;

        DeviceInfo(String name) {
            this.name = name;
            this.lastUpdate = System.currentTimeMillis();
        }
    }
}
