import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;

public class MainContainer {
    public static void main(String[] args) throws Exception {
        Runtime rt = Runtime.instance();
        Profile profile = new ProfileImpl();
        profile.setParameter(Profile.MAIN_HOST, "localhost");
        profile.setParameter(Profile.MAIN_PORT, "1099");
        profile.setParameter(Profile.GUI, "true");

        AgentContainer mainContainer = rt.createMainContainer(profile);

        AgentController mobileAgent = mainContainer.createNewAgent(
                "MobileAgent", "MobileAgent", null);
        AgentController controller = mainContainer.createNewAgent(
                "MigrationController", "MigrationController", null);

        mobileAgent.start();
        controller.start();

        System.out.println("Агенты созданы в главном контейнере");
    }
}
