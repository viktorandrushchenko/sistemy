import jade.core.Agent;
import jade.core.behaviours.TickerBehaviour;
import jade.lang.acl.ACLMessage;

public class MigrationController extends Agent {
    protected void setup() {
        System.out.println("Контроллер миграции запущен");

        addBehaviour(new TickerBehaviour(this, 10000) {
            protected void onTick() {
                try {
                    ACLMessage msg = new ACLMessage(ACLMessage.REQUEST);
                    msg.addReceiver(new jade.core.AID("MobileAgent", jade.core.AID.ISLOCALNAME));
                    msg.setContent("migrate");
                    send(msg);
                    System.out.println("Отправлена команда миграции для MobileAgent");
                } catch (Exception e) {
                    System.out.println("Ошибка: " + e.getMessage());
                }
            }
        });
    }
}