import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;

public class MobileAgent extends Agent {
    private int calculationCount = 0;
    private boolean inMainContainer = true;

    protected void setup() {
        System.out.println("Агент " + getLocalName() + " создан в " + here().getName());

        addBehaviour(new CyclicBehaviour(this) {
            public void action() {
                ACLMessage msg = receive(MessageTemplate.MatchPerformative(ACLMessage.REQUEST));
                if (msg != null) {
                    if (msg.getContent().equals("migrate")) {
                        String target = inMainContainer ? "Container-1" : "Main-Container";
                        System.out.println(getLocalName() + " мигрирует из " + here().getName() + " в " + target);
                        inMainContainer = !inMainContainer;
                        doMove(new jade.core.ContainerID(target, null));
                    } else {
                        calculationCount++;
                        ACLMessage reply = msg.createReply();
                        reply.setPerformative(ACLMessage.INFORM);
                        reply.setContent("Вычисление #" + calculationCount + " из " + here().getName());
                        send(reply);
                    }
                } else {
                    block();
                }
            }
        });
    }

    protected void afterMove() {
        System.out.println("✅ " + getLocalName() + " успешно мигрировал в " + here().getName());
    }
}