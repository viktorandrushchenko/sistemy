import jade.core.Agent;
import jade.core.behaviours.OneShotBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;

public class TestClientAgent extends Agent {

    @Override
    protected void setup() {
        System.out.println("Тестовый клиент запущен");

        addBehaviour(new OneShotBehaviour() {
            @Override
            public void action() {
                ACLMessage request = new ACLMessage(ACLMessage.REQUEST);
                request.addReceiver(new jade.core.AID("Coordinator", jade.core.AID.ISLOCALNAME));
                request.setLanguage("sum");
                request.setContent("1,100");
                send(request);

                System.out.println("Запрос отправлен координатору: сумма от 1 до 100");

                ACLMessage response = myAgent.blockingReceive(MessageTemplate.MatchPerformative(ACLMessage.INFORM));
                if (response != null) {
                    long result = Long.parseLong(response.getContent());
                    System.out.println("Получен итоговый результат: " + result);
                    System.out.println("Ожидаемый результат (1-100): " + (100L * 101 / 2));
                }
            }
        });
    }
}