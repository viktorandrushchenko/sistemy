import jade.core.Agent;
import jade.core.AID;
import jade.core.behaviours.FSMBehaviour;
import jade.core.behaviours.OneShotBehaviour;
import jade.core.behaviours.TickerBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.domain.FIPAException;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import java.util.*;

public class CoordinatorAgent extends Agent {
    private static final String STATE_WAITING = "waiting";
    private static final String STATE_PROCESSING = "processing";

    private Map<String, Long> calculatorResults;
    private Map<String, String> originalSenders;
    private int expectedResponses;
    private AID[] calculators;
    private ACLMessage currentRequest;

    @Override
    protected void setup() {
        calculatorResults = new HashMap<>();
        originalSenders = new HashMap<>();

        Object[] args = getArguments();
        if (args != null && args.length > 0) {
            String[] calculatorNames = args[0].toString().split(",");
            calculators = new AID[calculatorNames.length];
            for (int i = 0; i < calculatorNames.length; i++) {
                calculators[i] = new AID(calculatorNames[i].trim(), AID.ISLOCALNAME);
            }
        }

        FSMBehaviour fsm = new FSMBehaviour(this);

        fsm.registerFirstState(new WaitingState(), STATE_WAITING);
        fsm.registerState(new ProcessingState(), STATE_PROCESSING);

        fsm.registerDefaultTransition(STATE_WAITING, STATE_PROCESSING);
        fsm.registerDefaultTransition(STATE_PROCESSING, STATE_WAITING);

        addBehaviour(fsm);
    }

    private class WaitingState extends OneShotBehaviour {
        private MessageTemplate template = MessageTemplate.and(
                MessageTemplate.MatchPerformative(ACLMessage.REQUEST),
                MessageTemplate.MatchLanguage("sum")
        );

        @Override
        public void action() {
            currentRequest = myAgent.receive(template);
            if (currentRequest != null) {
                System.out.println(getLocalName() + ": получен запрос от клиента");
            }

            ACLMessage calculatorResponse = myAgent.receive(MessageTemplate.MatchPerformative(ACLMessage.CONFIRM));
            if (calculatorResponse != null) {
                processCalculatorResponse(calculatorResponse);
            }
        }

        @Override
        public int onEnd() {
            return currentRequest != null ? 1 : 0;
        }
    }

    private class ProcessingState extends OneShotBehaviour {
        @Override
        public void action() {
            if (currentRequest != null) {
                try {
                    String content = currentRequest.getContent();
                    String[] numbers = content.split(",");

                    if (numbers.length == 2) {
                        int A = Integer.parseInt(numbers[0].trim());
                        int B = Integer.parseInt(numbers[1].trim());

                        distributeCalculation(A, B, currentRequest.getSender().getLocalName());
                    }
                } catch (NumberFormatException e) {
                    ACLMessage reply = currentRequest.createReply();
                    reply.setPerformative(ACLMessage.FAILURE);
                    reply.setContent("Number parsing error");
                    send(reply);
                }

                currentRequest = null;
            }
        }

        private void distributeCalculation(int A, int B, String originalSender) {
            calculatorResults.clear();
            expectedResponses = calculators.length;

            String calculationId = generateCalculationId();
            originalSenders.put(calculationId, originalSender);

            int totalNumbers = Math.abs(B - A) + 1;
            int numbersPerCalculator = totalNumbers / calculators.length;
            int remainder = totalNumbers % calculators.length;

            int current = A;
            for (int i = 0; i < calculators.length; i++) {
                int numbersForThisCalculator = numbersPerCalculator;
                if (i < remainder) {
                    numbersForThisCalculator++;
                }

                int end = (A <= B) ? current + numbersForThisCalculator - 1 : current - numbersForThisCalculator + 1;

                ACLMessage task = new ACLMessage(ACLMessage.REQUEST);
                task.addReceiver(calculators[i]);
                task.setLanguage("sum");
                task.setContent(current + "," + end);
                task.setConversationId(calculationId);
                send(task);

                current = (A <= B) ? end + 1 : end - 1;
            }

            System.out.println(getLocalName() + ": распределил вычисления между " + calculators.length + " калькуляторами");
        }
    }

    private void processCalculatorResponse(ACLMessage msg) {
        String conversationId = msg.getConversationId();
        String calculatorName = msg.getSender().getLocalName();

        try {
            long result = Long.parseLong(msg.getContent());
            calculatorResults.put(calculatorName, result);

            if (calculatorResults.size() == expectedResponses) {
                long totalSum = 0;
                for (long partialSum : calculatorResults.values()) {
                    totalSum += partialSum;
                }

                String originalSender = originalSenders.get(conversationId);
                if (originalSender != null) {
                    ACLMessage finalResult = new ACLMessage(ACLMessage.INFORM);
                    finalResult.addReceiver(new AID(originalSender, AID.ISLOCALNAME));
                    finalResult.setContent(String.valueOf(totalSum));
                    send(finalResult);
                    System.out.println(getLocalName() + ": отправил итоговый результат клиенту");
                }

                calculatorResults.clear();
                originalSenders.remove(conversationId);
            }
        } catch (NumberFormatException e) {
        }
    }

    private String generateCalculationId() {
        return "calc_" + System.currentTimeMillis();
    }
}