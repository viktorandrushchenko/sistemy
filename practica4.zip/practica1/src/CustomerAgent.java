import jade.core.Agent;
import jade.core.AID;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.OneShotBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

public class CustomerAgent extends Agent {
    private AtomicInteger completedRequests = new AtomicInteger(0);
    private AtomicInteger refusedRequests = new AtomicInteger(0);
    private long startTime;

    @Override
    protected void setup() {
        System.out.println("Клиент-тестер запущен");

        addBehaviour(new OneShotBehaviour() {
            @Override
            public void action() {
                startTime = System.currentTimeMillis();

                for (int i = 0; i < 10; i++) {
                    String coordinator = "Coordinator" + (i % 2 + 1);
                    sendCalculationRequest(coordinator, 1, 100);

                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        addBehaviour(new ResponseBehaviour());
    }

    private void sendCalculationRequest(String coordinator, int A, int B) {
        ACLMessage request = new ACLMessage(ACLMessage.REQUEST);
        request.addReceiver(new AID(coordinator, AID.ISLOCALNAME));
        request.setLanguage("sum");
        request.setContent(A + "," + B);
        request.setConversationId("customer_" + System.currentTimeMillis());
        send(request);

        System.out.println("Отправлен запрос координатору " + coordinator + ": сумма от " + A + " до " + B);
    }

    private class ResponseBehaviour extends CyclicBehaviour {
        @Override
        public void action() {
            ACLMessage informMsg = myAgent.receive(MessageTemplate.MatchPerformative(ACLMessage.INFORM));
            if (informMsg != null) {
                completedRequests.incrementAndGet();
                long result = Long.parseLong(informMsg.getContent());
                System.out.println("Получен результат: " + result + " (завершено: " + completedRequests.get() + ")");
                checkTestCompletion();
                return;
            }

            ACLMessage refuseMsg = myAgent.receive(MessageTemplate.MatchPerformative(ACLMessage.REFUSE));
            if (refuseMsg != null) {
                refusedRequests.incrementAndGet();
                System.out.println("Получен отказ: " + refuseMsg.getContent() + " (отказов: " + refusedRequests.get() + ")");
                return;
            }

            block();
        }
    }

    private void checkTestCompletion() {
        if (completedRequests.get() + refusedRequests.get() >= 10) {
            long endTime = System.currentTimeMillis();
            System.out.println("=== ТЕСТ ЗАВЕРШЕН ===");
            System.out.println("Успешно: " + completedRequests.get());
            System.out.println("Отказов: " + refusedRequests.get());
            System.out.println("Время: " + (endTime - startTime) + " мс");
        }
    }
}