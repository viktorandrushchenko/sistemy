import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;

public class Main {
    public static void main(String[] args) {
        Runtime rt = Runtime.instance();
        Profile profile = new ProfileImpl();
        profile.setParameter(Profile.MAIN_HOST, "localhost");
        profile.setParameter(Profile.MAIN_PORT, "1099");
        profile.setParameter(Profile.GUI, "true");

        AgentContainer mainContainer = rt.createMainContainer(profile);

        try {
            System.out.println("Запускаем систему с выбором координатора...");

            Thread.sleep(2000);

            AgentController calc1 = mainContainer.createNewAgent(
                    "Calculator1", "CalculatorAgent", new Object[]{});
            AgentController calc2 = mainContainer.createNewAgent(
                    "Calculator2", "CalculatorAgent", new Object[]{});
            AgentController calc3 = mainContainer.createNewAgent(
                    "Calculator3", "CalculatorAgent", new Object[]{});

            calc1.start();
            calc2.start();
            calc3.start();

            Thread.sleep(10000);

            AgentController customer = mainContainer.createNewAgent(
                    "Customer", "CustomerAgent", new Object[]{});
            customer.start();

            Thread.sleep(15000);

            System.out.println("\n=== ТЕСТ KILL-SWITCH ===");
            System.out.println("Для остановки координатора отправьте сообщение с содержанием 'shutdown'");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}