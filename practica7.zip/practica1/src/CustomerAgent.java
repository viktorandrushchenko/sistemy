import jade.core.Agent;
import jade.core.AID;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.TickerBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.domain.FIPAException;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import java.util.Random;

public class CustomerAgent extends Agent {
    private AID currentCoordinator;
    private Random random = new Random();
    private int successfulRequests = 0;
    private int failedRequests = 0;

    @Override
    protected void setup() {
        System.out.println("Заказчик " + getLocalName() + " запущен");

        addBehaviour(new CoordinatorDiscoveryBehaviour());
        addBehaviour(new RequestSchedulerBehaviour());
        addBehaviour(new ResponseHandlerBehaviour());
    }

    private class CoordinatorDiscoveryBehaviour extends TickerBehaviour {
        public CoordinatorDiscoveryBehaviour() {
            super(CustomerAgent.this, 8000);
        }

        @Override
        protected void onTick() {
            findCoordinator();
        }

        private void findCoordinator() {
            try {
                DFAgentDescription template = new DFAgentDescription();
                ServiceDescription sd = new ServiceDescription();
                sd.setType("coordinator");
                template.addServices(sd);

                DFAgentDescription[] results = DFService.search(myAgent, template);

                if (results.length > 0) {
                    AID newCoordinator = results[0].getName();
                    if (!newCoordinator.equals(currentCoordinator)) {
                        currentCoordinator = newCoordinator;
                        System.out.println("🔄 Заказчик нашел нового координатора: " + currentCoordinator.getLocalName());
                    }
                } else {
                    currentCoordinator = null;
                    System.out.println("⚠️ Заказчик не нашел координаторов");
                }

            } catch (FIPAException e) {
                e.printStackTrace();
            }
        }
    }

    private class RequestSchedulerBehaviour extends TickerBehaviour {
        public RequestSchedulerBehaviour() {
            super(CustomerAgent.this, 5000);
        }

        @Override
        protected void onTick() {
            if (currentCoordinator != null) {
                sendCalculationRequest();
            } else {
                System.out.println("Заказчик: нет координатора для отправки запроса");
            }
        }

        private void sendCalculationRequest() {
            int A = random.nextInt(50) + 1;
            int B = A + random.nextInt(100) + 50;

            ACLMessage request = new ACLMessage(ACLMessage.REQUEST);
            request.addReceiver(currentCoordinator);
            request.setContent(A + "," + B);
            request.setReplyWith("req_" + System.currentTimeMillis());
            send(request);

            System.out.println("Заказчик отправил запрос координатору " + currentCoordinator.getLocalName() +
                    ": сумма от " + A + " до " + B);
        }
    }

    private class ResponseHandlerBehaviour extends CyclicBehaviour {
        @Override
        public void action() {
            ACLMessage inform = myAgent.receive(MessageTemplate.MatchPerformative(ACLMessage.INFORM));
            if (inform != null) {
                successfulRequests++;
                long result = Long.parseLong(inform.getContent());
                System.out.println("Заказчик получил результат: " + result +
                        " (успешных: " + successfulRequests + ")");
                return;
            }

            ACLMessage refuse = myAgent.receive(MessageTemplate.MatchPerformative(ACLMessage.REFUSE));
            if (refuse != null) {
                failedRequests++;
                System.out.println("Заказчик получил отказ: " + refuse.getContent() +
                        " (отказов: " + failedRequests + ")");
                return;
            }

            ACLMessage failure = myAgent.receive(MessageTemplate.MatchPerformative(ACLMessage.FAILURE));
            if (failure != null) {
                failedRequests++;
                System.out.println("Заказчик получил ошибку: " + failure.getContent() +
                        " (ошибок: " + failedRequests + ")");
                return;
            }

            block();
        }
    }
}
