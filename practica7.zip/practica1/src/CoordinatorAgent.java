import jade.core.Agent;
import jade.core.AID;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.OneShotBehaviour;
import jade.core.behaviours.TickerBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.domain.FIPAException;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import java.util.Random;

public class CoordinatorAgent extends Agent {
    private boolean active = true;
    private Random random = new Random();
    private int requestsProcessed = 0;

    @Override
    protected void setup() {
        System.out.println("Координатор " + getLocalName() + " запущен");

        registerAsCoordinator();

        addBehaviour(new RequestHandlerBehaviour());
        addBehaviour(new KillSwitchBehaviour());
        addBehaviour(new HealthCheckBehaviour());

        System.out.println("Kill-switch: отправьте сообщение с содержанием 'shutdown' для остановки");
    }

    private void registerAsCoordinator() {
        try {
            DFAgentDescription dfd = new DFAgentDescription();
            dfd.setName(getAID());
            ServiceDescription sd = new ServiceDescription();
            sd.setType("coordinator");
            sd.setName("calculation-coordinator");
            dfd.addServices(sd);
            DFService.register(this, dfd);
            System.out.println(getLocalName() + " зарегистрирован как координатор в DF");
        } catch (FIPAException e) {
            e.printStackTrace();
        }
    }

    private void deregister() {
        try {
            DFService.deregister(this);
            System.out.println(getLocalName() + " дерегистрирован из DF");
        } catch (FIPAException e) {
            e.printStackTrace();
        }
    }

    private class RequestHandlerBehaviour extends CyclicBehaviour {
        private MessageTemplate template = MessageTemplate.MatchPerformative(ACLMessage.REQUEST);

        @Override
        public void action() {
            if (!active) {
                block(1000);
                return;
            }

            ACLMessage msg = myAgent.receive(template);
            if (msg != null) {
                if (msg.getContent().equals("shutdown")) {
                    handleShutdownRequest(msg);
                } else {
                    handleCalculationRequest(msg);
                }
            } else {
                block();
            }
        }

        private void handleShutdownRequest(ACLMessage msg) {
            System.out.println("Получена команда shutdown от " + msg.getSender().getLocalName());

            ACLMessage reply = msg.createReply();
            reply.setPerformative(ACLMessage.CONFIRM);
            reply.setContent("Coordinator shutting down");
            send(reply);

            active = false;
            deregister();

            addBehaviour(new OneShotBehaviour() {
                @Override
                public void action() {
                    try {
                        Thread.sleep(2000);
                        doDelete();
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                }
            });
        }

        private void handleCalculationRequest(ACLMessage msg) {
            requestsProcessed++;
            System.out.println(getLocalName() + " обрабатывает запрос #" + requestsProcessed);

            try {
                String content = msg.getContent();
                String[] numbers = content.split(",");
                int A = Integer.parseInt(numbers[0].trim());
                int B = Integer.parseInt(numbers[1].trim());

                long result = simulateCalculation(A, B);

                ACLMessage reply = msg.createReply();
                reply.setPerformative(ACLMessage.INFORM);
                reply.setContent(String.valueOf(result));
                send(reply);

                System.out.println(getLocalName() + " отправил результат: " + result);

            } catch (Exception e) {
                ACLMessage reply = msg.createReply();
                reply.setPerformative(ACLMessage.FAILURE);
                reply.setContent("Error: " + e.getMessage());
                send(reply);
            }
        }

        private long simulateCalculation(int A, int B) throws InterruptedException {
            Thread.sleep(1000 + random.nextInt(2000));
            int n = Math.abs(B - A) + 1;
            return (long) n * (A + B) / 2;
        }
    }

    private class KillSwitchBehaviour extends CyclicBehaviour {
        @Override
        public void action() {
            if (!active) {
                ACLMessage msg = myAgent.receive();
                if (msg != null && msg.getPerformative() == ACLMessage.REQUEST) {
                    ACLMessage refuse = msg.createReply();
                    refuse.setPerformative(ACLMessage.REFUSE);
                    refuse.setContent("Coordinator is shutting down");
                    send(refuse);
                } else {
                    block(500);
                }
            } else {
                block(1000);
            }
        }
    }

    private class HealthCheckBehaviour extends TickerBehaviour {
        public HealthCheckBehaviour() {
            super(CoordinatorAgent.this, 10000);
        }

        @Override
        protected void onTick() {
            if (active) {
                System.out.println("Координатор " + getLocalName() + " активен, обработано запросов: " + requestsProcessed);

                if (random.nextDouble() < 0.1) {
                    System.out.println("🎲 Случайное отключение координатора " + getLocalName());
                    active = false;
                    deregister();
                    addBehaviour(new OneShotBehaviour() {
                        @Override
                        public void action() {
                            doDelete();
                        }
                    });
                }
            }
        }
    }

    @Override
    protected void takeDown() {
        if (active) {
            deregister();
        }
        System.out.println("Координатор " + getLocalName() + " завершает работу");
    }
}
