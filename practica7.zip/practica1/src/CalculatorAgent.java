import jade.core.Agent;
import jade.core.AID;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.OneShotBehaviour;
import jade.core.behaviours.TickerBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.domain.FIPAException;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import java.util.*;

public class CalculatorAgent extends Agent {
    private static final String COORDINATOR_SERVICE = "coordinator";
    private AID currentCoordinator;
    private boolean isCoordinator = false;
    private Random random = new Random();

    @Override
    protected void setup() {
        System.out.println("Калькулятор " + getLocalName() + " запущен");

        registerAsCalculator();

        addBehaviour(new CoordinatorElectionBehaviour());
        addBehaviour(new CalculationBehaviour());
        addBehaviour(new CoordinatorServiceBehaviour());

        addBehaviour(new TickerBehaviour(this, 15000) {
            @Override
            protected void onTick() {
                checkCoordinatorStatus();
            }
        });
    }

    private void registerAsCalculator() {
        try {
            DFAgentDescription dfd = new DFAgentDescription();
            dfd.setName(getAID());
            ServiceDescription sd = new ServiceDescription();
            sd.setType("calculator");
            sd.setName("sum-calculator");
            dfd.addServices(sd);
            DFService.register(this, dfd);
        } catch (FIPAException e) {
            e.printStackTrace();
        }
    }

    private class CoordinatorElectionBehaviour extends OneShotBehaviour {
        @Override
        public void action() {
            try {
                Thread.sleep(3000 + random.nextInt(5000));

                DFAgentDescription template = new DFAgentDescription();
                ServiceDescription sd = new ServiceDescription();
                sd.setType(COORDINATOR_SERVICE);
                template.addServices(sd);

                DFAgentDescription[] results = DFService.search(myAgent, template);

                if (results.length == 0) {
                    becomeCoordinator();
                } else {
                    currentCoordinator = results[0].getName();
                    System.out.println(getLocalName() + ": найден координатор " + currentCoordinator.getLocalName());
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        private void becomeCoordinator() {
            try {
                DFAgentDescription dfd = new DFAgentDescription();
                dfd.setName(getAID());
                ServiceDescription sd = new ServiceDescription();
                sd.setType(COORDINATOR_SERVICE);
                sd.setName("calculation-coordinator");
                dfd.addServices(sd);
                DFService.register(myAgent, dfd);

                isCoordinator = true;
                System.out.println("🎯 " + getLocalName() + " стал координатором!");

            } catch (FIPAException e) {
                e.printStackTrace();
            }
        }
    }

    private class CalculationBehaviour extends CyclicBehaviour {
        private MessageTemplate template = MessageTemplate.and(
                MessageTemplate.MatchPerformative(ACLMessage.REQUEST),
                MessageTemplate.MatchLanguage("sum")
        );

        @Override
        public void action() {
            ACLMessage msg = myAgent.receive(template);
            if (msg != null) {
                if (isCoordinator) {
                    handleCoordinatorRequest(msg);
                } else {
                    handleCalculatorRequest(msg);
                }
            } else {
                block();
            }
        }

        private void handleCalculatorRequest(ACLMessage msg) {
            try {
                String content = msg.getContent();
                String[] numbers = content.split(",");
                int A = Integer.parseInt(numbers[0].trim());
                int B = Integer.parseInt(numbers[1].trim());

                long result = calculateSum(A, B);

                ACLMessage reply = msg.createReply();
                reply.setPerformative(ACLMessage.INFORM);
                reply.setContent(String.valueOf(result));
                send(reply);

            } catch (Exception e) {
                ACLMessage reply = msg.createReply();
                reply.setPerformative(ACLMessage.FAILURE);
                reply.setContent("Error: " + e.getMessage());
                send(reply);
            }
        }

        private void handleCoordinatorRequest(ACLMessage msg) {
            System.out.println("Координатор " + getLocalName() + " получил запрос от " + msg.getSender().getLocalName());

            try {
                String content = msg.getContent();
                String[] numbers = content.split(",");
                int A = Integer.parseInt(numbers[0].trim());
                int B = Integer.parseInt(numbers[1].trim());

                distributeCalculation(A, B, msg.getSender());

            } catch (Exception e) {
                ACLMessage reply = msg.createReply();
                reply.setPerformative(ACLMessage.FAILURE);
                reply.setContent("Error: " + e.getMessage());
                send(reply);
            }
        }

        private long calculateSum(int A, int B) {
            try {
                Thread.sleep(2000 + random.nextInt(2000));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            int n = Math.abs(B - A) + 1;
            return (long) n * (A + B) / 2;
        }

        private void distributeCalculation(int A, int B, AID client) {
            try {
                DFAgentDescription template = new DFAgentDescription();
                ServiceDescription sd = new ServiceDescription();
                sd.setType("calculator");
                template.addServices(sd);

                DFAgentDescription[] calculators = DFService.search(this.getAgent(), template);

                if (calculators.length == 0) {
                    throw new RuntimeException("No calculators available");
                }

                int totalNumbers = Math.abs(B - A) + 1;
                int numbersPerCalculator = totalNumbers / calculators.length;
                int remainder = totalNumbers % calculators.length;

                Map<String, Long> results = new HashMap<>();
                int current = A;

                for (int i = 0; i < calculators.length; i++) {
                    int numbersForThisCalculator = numbersPerCalculator;
                    if (i < remainder) {
                        numbersForThisCalculator++;
                    }

                    int end = (A <= B) ? current + numbersForThisCalculator - 1 : current - numbersForThisCalculator + 1;

                    ACLMessage task = new ACLMessage(ACLMessage.REQUEST);
                    task.addReceiver(calculators[i].getName());
                    task.setLanguage("sum");
                    task.setContent(current + "," + end);
                    task.setReplyWith("task_" + System.currentTimeMillis() + "_" + i);
                    send(task);

                    current = (A <= B) ? end + 1 : end - 1;
                }

                ACLMessage inform = new ACLMessage(ACLMessage.INFORM);
                inform.addReceiver(client);
                inform.setContent("Calculation distributed to " + calculators.length + " calculators");
                send(inform);

            } catch (Exception e) {
                ACLMessage failure = new ACLMessage(ACLMessage.FAILURE);
                failure.addReceiver(client);
                failure.setContent("Distribution failed: " + e.getMessage());
                send(failure);
            }
        }
    }

    private class CoordinatorServiceBehaviour extends CyclicBehaviour {
        @Override
        public void action() {
            if (isCoordinator) {
                ACLMessage msg = myAgent.receive(MessageTemplate.MatchPerformative(ACLMessage.REQUEST));
                if (msg != null && !msg.getLanguage().equals("sum")) {
                    handleClientRequest(msg);
                } else {
                    block();
                }
            } else {
                block();
            }
        }

        private void handleClientRequest(ACLMessage msg) {
            System.out.println("Координатор " + getLocalName() + " получил клиентский запрос");

            ACLMessage reply = msg.createReply();
            reply.setPerformative(ACLMessage.AGREE);
            reply.setContent("Request accepted by coordinator " + getLocalName());
            send(reply);

            try {
                String content = msg.getContent();
                String[] numbers = content.split(",");
                int A = Integer.parseInt(numbers[0].trim());
                int B = Integer.parseInt(numbers[1].trim());

                long result = A + B;

                ACLMessage resultMsg = new ACLMessage(ACLMessage.INFORM);
                resultMsg.addReceiver(msg.getSender());
                resultMsg.setContent(String.valueOf(result));
                send(resultMsg);

            } catch (Exception e) {
                ACLMessage failure = new ACLMessage(ACLMessage.FAILURE);
                failure.addReceiver(msg.getSender());
                failure.setContent("Error: " + e.getMessage());
                send(failure);
            }
        }
    }

    private void checkCoordinatorStatus() {
        if (!isCoordinator) {
            try {
                DFAgentDescription template = new DFAgentDescription();
                ServiceDescription sd = new ServiceDescription();
                sd.setType(COORDINATOR_SERVICE);
                template.addServices(sd);

                DFAgentDescription[] results = DFService.search(this, template);

                if (results.length == 0) {
                    System.out.println(getLocalName() + ": координатор пропал, запускаем выборы");
                    addBehaviour(new CoordinatorElectionBehaviour());
                } else {
                    AID newCoordinator = results[0].getName();
                    if (!newCoordinator.equals(currentCoordinator)) {
                        currentCoordinator = newCoordinator;
                        System.out.println(getLocalName() + ": сменился координатор на " + currentCoordinator.getLocalName());
                    }
                }

            } catch (FIPAException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void takeDown() {
        if (isCoordinator) {
            try {
                DFService.deregister(this);
                System.out.println("Координатор " + getLocalName() + " дерегистрирован");
            } catch (FIPAException e) {
                e.printStackTrace();
            }
        }
    }
}