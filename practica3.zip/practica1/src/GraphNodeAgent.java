import jade.core.Agent;
import jade.core.AID;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import java.util.*;

public class GraphNodeAgent extends Agent {
    private Set<String> neighbors;
    private Map<String, RouteRequest> pendingRequests;

    @Override
    protected void setup() {
        Object[] args = getArguments();
        neighbors = new HashSet<>();

        if (args != null && args.length > 0) {
            String[] neighborNames = args[0].toString().split(",");
            for (String name : neighborNames) {
                neighbors.add(name.trim());
            }
        }

        pendingRequests = new HashMap<>();
        addBehaviour(new RouteRequestBehaviour());
        addBehaviour(new RouteResponseBehaviour());
    }

    private class RouteRequestBehaviour extends CyclicBehaviour {
        private MessageTemplate template = MessageTemplate.MatchPerformative(ACLMessage.REQUEST);

        @Override
        public void action() {
            ACLMessage msg = myAgent.receive(template);

            if (msg != null) {
                String targetNode = msg.getContent();
                String requestId = msg.getConversationId();

                if (getLocalName().equals(targetNode)) {
                    ACLMessage reply = msg.createReply();
                    reply.setPerformative(ACLMessage.CONFIRM);
                    reply.setContent(getLocalName());
                    send(reply);
                } else {
                    pendingRequests.put(requestId, new RouteRequest(msg.getSender(), targetNode, new ArrayList<>()));
                    boolean forwarded = forwardToNeighbors(requestId, targetNode, new ArrayList<>(Arrays.asList(getLocalName())));

                    if (!forwarded) {
                        ACLMessage reply = msg.createReply();
                        reply.setPerformative(ACLMessage.DISCONFIRM);
                        send(reply);
                        pendingRequests.remove(requestId);
                    }
                }
            } else {
                block();
            }
        }

        private boolean forwardToNeighbors(String requestId, String targetNode, List<String> path) {
            boolean forwarded = false;

            for (String neighbor : neighbors) {
                if (!path.contains(neighbor)) {
                    ACLMessage forwardMsg = new ACLMessage(ACLMessage.REQUEST);
                    forwardMsg.addReceiver(new AID(neighbor, AID.ISLOCALNAME));
                    forwardMsg.setContent(targetNode);
                    forwardMsg.setConversationId(requestId);
                    send(forwardMsg);
                    forwarded = true;
                }
            }

            return forwarded;
        }
    }

    private class RouteResponseBehaviour extends CyclicBehaviour {
        private MessageTemplate confirmTemplate = MessageTemplate.MatchPerformative(ACLMessage.CONFIRM);
        private MessageTemplate disconfirmTemplate = MessageTemplate.MatchPerformative(ACLMessage.DISCONFIRM);

        @Override
        public void action() {
            ACLMessage confirmMsg = myAgent.receive(confirmTemplate);
            if (confirmMsg != null) {
                processConfirm(confirmMsg);
                return;
            }

            ACLMessage disconfirmMsg = myAgent.receive(disconfirmTemplate);
            if (disconfirmMsg != null) {
                processDisconfirm(disconfirmMsg);
                return;
            }

            block();
        }

        private void processConfirm(ACLMessage msg) {
            String requestId = msg.getConversationId();
            RouteRequest request = pendingRequests.get(requestId);

            if (request != null) {
                String fullPath = msg.getContent() + "\n" + String.join("\n", request.path);
                String[] pathParts = fullPath.split("\n");

                if (request.originalSender != null) {
                    ACLMessage reply = new ACLMessage(ACLMessage.CONFIRM);
                    reply.addReceiver(request.originalSender);
                    reply.setContent(fullPath);
                    send(reply);
                }

                pendingRequests.remove(requestId);
            }
        }

        private void processDisconfirm(ACLMessage msg) {
            String requestId = msg.getConversationId();
            RouteRequest request = pendingRequests.get(requestId);

            if (request != null) {
                boolean allResponsesReceived = checkAllResponsesReceived(requestId);

                if (allResponsesReceived) {
                    if (request.originalSender != null) {
                        ACLMessage reply = new ACLMessage(ACLMessage.DISCONFIRM);
                        reply.addReceiver(request.originalSender);
                        send(reply);
                    }
                    pendingRequests.remove(requestId);
                }
            }
        }

        private boolean checkAllResponsesReceived(String requestId) {
            return true;
        }
    }

    private static class RouteRequest {
        AID originalSender;
        String targetNode;
        List<String> path;

        RouteRequest(AID originalSender, String targetNode, List<String> path) {
            this.originalSender = originalSender;
            this.targetNode = targetNode;
            this.path = new ArrayList<>(path);
        }
    }
}