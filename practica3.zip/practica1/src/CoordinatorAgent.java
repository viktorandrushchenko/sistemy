import jade.core.Agent;
import jade.core.AID;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.TickerBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.domain.FIPAException;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import java.util.*;

public class CoordinatorAgent extends Agent {
    private Map<String, Long> calculatorResults;
    private Map<String, String> originalSenders;
    private Map<String, int[]> requestRanges;
    private int expectedResponses;
    private AID[] calculators;

    @Override
    protected void setup() {
        calculatorResults = new HashMap<>();
        originalSenders = new HashMap<>();
        requestRanges = new HashMap<>();

        addBehaviour(new RequestHandlerBehaviour());
        addBehaviour(new CalculatorDiscoveryBehaviour(this, 10000));

        updateCalculators();
    }

    private class RequestHandlerBehaviour extends CyclicBehaviour {
        private MessageTemplate template = MessageTemplate.and(
                MessageTemplate.MatchPerformative(ACLMessage.REQUEST),
                MessageTemplate.MatchLanguage("sum")
        );

        @Override
        public void action() {
            ACLMessage msg = myAgent.receive(template);

            if (msg != null) {
                processClientRequest(msg);
            } else {
                ACLMessage response = myAgent.receive(MessageTemplate.MatchPerformative(ACLMessage.CONFIRM));
                if (response != null) {
                    processCalculatorResponse(response);
                } else {
                    block();
                }
            }
        }

        private void processClientRequest(ACLMessage msg) {
            try {
                String content = msg.getContent();
                String[] numbers = content.split(",");

                if (numbers.length == 2) {
                    int A = Integer.parseInt(numbers[0].trim());
                    int B = Integer.parseInt(numbers[1].trim());

                    distributeCalculation(A, B, msg.getSender().getLocalName());

                } else {
                    sendErrorToClient(msg, "Invalid format");
                }

            } catch (NumberFormatException e) {
                sendErrorToClient(msg, "Number parsing error");
            }
        }

        private void distributeCalculation(int A, int B, String originalSender) {
            if (calculators == null || calculators.length == 0) {
                return;
            }

            int totalNumbers = Math.abs(B - A) + 1;
            int numbersPerCalculator = totalNumbers / calculators.length;
            int remainder = totalNumbers % calculators.length;

            calculatorResults.clear();
            expectedResponses = calculators.length;

            String calculationId = generateCalculationId();
            originalSenders.put(calculationId, originalSender);

            int current = A;
            for (int i = 0; i < calculators.length; i++) {
                int numbersForThisCalculator = numbersPerCalculator;
                if (i < remainder) {
                    numbersForThisCalculator++;
                }

                int end = (A <= B) ? current + numbersForThisCalculator - 1 : current - numbersForThisCalculator + 1;

                requestRanges.put(calculationId + "_" + i, new int[]{current, end});

                ACLMessage task = new ACLMessage(ACLMessage.REQUEST);
                task.addReceiver(calculators[i]);
                task.setLanguage("sum");
                task.setContent(current + "," + end);
                task.setConversationId(calculationId);
                send(task);

                current = (A <= B) ? end + 1 : end - 1;
            }
        }

        private void processCalculatorResponse(ACLMessage msg) {
            String conversationId = msg.getConversationId();
            String calculatorName = msg.getSender().getLocalName();

            try {
                long result = Long.parseLong(msg.getContent());
                calculatorResults.put(calculatorName, result);

                if (calculatorResults.size() == expectedResponses) {
                    long totalSum = 0;
                    for (long partialSum : calculatorResults.values()) {
                        totalSum += partialSum;
                    }

                    String originalSender = originalSenders.get(conversationId);
                    if (originalSender != null) {
                        ACLMessage finalResult = new ACLMessage(ACLMessage.INFORM);
                        finalResult.addReceiver(new AID(originalSender, AID.ISLOCALNAME));
                        finalResult.setContent(String.valueOf(totalSum));
                        send(finalResult);
                    }

                    calculatorResults.clear();
                    originalSenders.remove(conversationId);
                }

            } catch (NumberFormatException e) {
            }
        }

        private String generateCalculationId() {
            return "calc_" + System.currentTimeMillis() + "_" + Math.random();
        }

        private void sendErrorToClient(ACLMessage originalMsg, String error) {
            ACLMessage reply = originalMsg.createReply();
            reply.setPerformative(ACLMessage.FAILURE);
            reply.setContent(error);
            send(reply);
        }
    }

    private class CalculatorDiscoveryBehaviour extends TickerBehaviour {
        public CalculatorDiscoveryBehaviour(Agent a, long period) {
            super(a, period);
        }

        @Override
        protected void onTick() {
            updateCalculators();
        }
    }

    private void updateCalculators() {
        DFAgentDescription template = new DFAgentDescription();
        ServiceDescription sd = new ServiceDescription();
        sd.setType("calculator");
        template.addServices(sd);

        try {
            DFAgentDescription[] result = DFService.search(this, template);
            calculators = new AID[result.length];
            for (int i = 0; i < result.length; i++) {
                calculators[i] = result[i].getName();
            }
        } catch (FIPAException e) {
            e.printStackTrace();
        }
    }
}