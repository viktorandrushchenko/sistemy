import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.domain.FIPAException;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;

public class CalculatorAgent extends Agent {

    @Override
    protected void setup() {
        DFAgentDescription dfd = new DFAgentDescription();
        dfd.setName(getAID());

        ServiceDescription sd = new ServiceDescription();
        sd.setType("calculator");
        sd.setName("sum-calculator");
        sd.addLanguages("sum");

        dfd.addServices(sd);

        try {
            DFService.register(this, dfd);
        } catch (FIPAException e) {
            e.printStackTrace();
        }

        addBehaviour(new RequestHandlerBehaviour());
    }

    @Override
    protected void takeDown() {
        try {
            DFService.deregister(this);
        } catch (FIPAException e) {
            e.printStackTrace();
        }
    }

    private class RequestHandlerBehaviour extends CyclicBehaviour {
        private MessageTemplate template = MessageTemplate.and(
                MessageTemplate.MatchPerformative(ACLMessage.REQUEST),
                MessageTemplate.MatchLanguage("sum")
        );

        @Override
        public void action() {
            ACLMessage msg = myAgent.receive(template);

            if (msg != null) {
                try {
                    String content = msg.getContent();
                    String[] numbers = content.split(",");

                    if (numbers.length == 2) {
                        int A = Integer.parseInt(numbers[0].trim());
                        int B = Integer.parseInt(numbers[1].trim());

                        long sum = calculateSum(A, B);

                        ACLMessage reply = msg.createReply();
                        reply.setPerformative(ACLMessage.CONFIRM);
                        reply.setContent(String.valueOf(sum));
                        send(reply);
                    } else {
                        ACLMessage reply = msg.createReply();
                        reply.setPerformative(ACLMessage.FAILURE);
                        reply.setContent("Invalid format");
                        send(reply);
                    }

                } catch (NumberFormatException e) {
                    ACLMessage reply = msg.createReply();
                    reply.setPerformative(ACLMessage.FAILURE);
                    reply.setContent("Number parsing error");
                    send(reply);
                }
            } else {
                block();
            }
        }

        private long calculateSum(int A, int B) {
            int n = Math.abs(B - A) + 1;
            return (long) n * (A + B) / 2;
        }
    }
}