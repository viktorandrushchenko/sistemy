import jade.core.Agent;
import jade.core.AID;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import java.util.*;

public class CoordinatorAgent extends Agent {
    private Map<String, Long> calculatorResults;
    private Map<String, String> originalSenders;
    private Map<String, int[]> requestRanges;
    private int expectedResponses;

    private AID[] calculators;

    @Override
    protected void setup() {
        Object[] args = getArguments();
        if (args != null && args.length > 0) {
            String[] calculatorNames = args[0].toString().split(",");
            calculators = new AID[calculatorNames.length];
            for (int i = 0; i < calculatorNames.length; i++) {
                calculators[i] = new AID(calculatorNames[i].trim(), AID.ISLOCALNAME);
            }
            System.out.println("Координатор получил " + calculators.length + " вычислителей");
        } else {
            System.out.println("Ошибка: не переданы имена вычислителей");
            doDelete();
            return;
        }

        calculatorResults = new HashMap<>();
        originalSenders = new HashMap<>();
        requestRanges = new HashMap<>();

        System.out.println("Агент-координатор " + getLocalName() + " запущен");

        addBehaviour(new RequestHandlerBehaviour());
    }

    private class RequestHandlerBehaviour extends CyclicBehaviour {
        private MessageTemplate template = MessageTemplate.and(
                MessageTemplate.MatchPerformative(ACLMessage.REQUEST),
                MessageTemplate.MatchLanguage("sum")
        );

        @Override
        public void action() {
            ACLMessage msg = myAgent.receive(template);

            if (msg != null) {
                processClientRequest(msg);
            } else {
                ACLMessage response = myAgent.receive(MessageTemplate.MatchPerformative(ACLMessage.CONFIRM));
                if (response != null) {
                    processCalculatorResponse(response);
                } else {
                    block();
                }
            }
        }

        private void processClientRequest(ACLMessage msg) {
            try {
                String content = msg.getContent();
                String[] numbers = content.split(",");

                if (numbers.length == 2) {
                    int A = Integer.parseInt(numbers[0].trim());
                    int B = Integer.parseInt(numbers[1].trim());

                    System.out.println("Координатор получил запрос: сумма от " + A + " до " + B);

                    distributeCalculation(A, B, msg.getSender().getLocalName());

                } else {
                    sendErrorToClient(msg, "Неверный формат данных");
                }

            } catch (NumberFormatException e) {
                sendErrorToClient(msg, "Ошибка преобразования чисел");
            }
        }

        private void distributeCalculation(int A, int B, String originalSender) {
            int totalNumbers = Math.abs(B - A) + 1;
            int numbersPerCalculator = totalNumbers / calculators.length;
            int remainder = totalNumbers % calculators.length;

            System.out.println("Распределение: " + totalNumbers + " чисел на " + calculators.length + " вычислителей");

            calculatorResults.clear();
            expectedResponses = calculators.length;

            String calculationId = generateCalculationId();
            originalSenders.put(calculationId, originalSender);

            int current = A;
            for (int i = 0; i < calculators.length; i++) {
                int numbersForThisCalculator = numbersPerCalculator;
                if (i < remainder) {
                    numbersForThisCalculator++;
                }

                int end = (A <= B) ? current + numbersForThisCalculator - 1 : current - numbersForThisCalculator + 1;

                requestRanges.put(calculationId + "_" + i, new int[]{current, end});

                ACLMessage task = new ACLMessage(ACLMessage.REQUEST);
                task.addReceiver(calculators[i]);
                task.setLanguage("sum");
                task.setContent(current + "," + end);
                task.setConversationId(calculationId);
                send(task);

                System.out.println("Отправлено вычислителю " + calculators[i].getLocalName() +
                        ": от " + current + " до " + end);

                current = (A <= B) ? end + 1 : end - 1;
            }
        }

        private void processCalculatorResponse(ACLMessage msg) {
            String conversationId = msg.getConversationId();
            String calculatorName = msg.getSender().getLocalName();

            try {
                long result = Long.parseLong(msg.getContent());
                calculatorResults.put(calculatorName, result);

                System.out.println("Получен результат от " + calculatorName + ": " + result);

                if (calculatorResults.size() == expectedResponses) {
                    long totalSum = 0;
                    for (long partialSum : calculatorResults.values()) {
                        totalSum += partialSum;
                    }

                    String originalSender = originalSenders.get(conversationId);
                    if (originalSender != null) {
                        ACLMessage finalResult = new ACLMessage(ACLMessage.INFORM);
                        finalResult.addReceiver(new AID(originalSender, AID.ISLOCALNAME));
                        finalResult.setContent(String.valueOf(totalSum));
                        send(finalResult);

                        System.out.println("Итоговая сумма отправлена клиенту " + originalSender + ": " + totalSum);
                    }

                    calculatorResults.clear();
                    originalSenders.remove(conversationId);
                }

            } catch (NumberFormatException e) {
                System.out.println("Ошибка парсинга результата от " + calculatorName);
            }
        }

        private String generateCalculationId() {
            return "calc_" + System.currentTimeMillis() + "_" + Math.random();
        }

        private void sendErrorToClient(ACLMessage originalMsg, String error) {
            ACLMessage reply = originalMsg.createReply();
            reply.setPerformative(ACLMessage.FAILURE);
            reply.setContent(error);
            send(reply);
        }
    }
}