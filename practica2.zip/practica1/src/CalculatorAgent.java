import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;

public class CalculatorAgent extends Agent {

    @Override
    protected void setup() {
        System.out.println("Агент-вычислитель " + getLocalName() + " запущен");

        addBehaviour(new RequestHandlerBehaviour());
    }

    private class RequestHandlerBehaviour extends CyclicBehaviour {
        private MessageTemplate template = MessageTemplate.and(
                MessageTemplate.MatchPerformative(ACLMessage.REQUEST),
                MessageTemplate.MatchLanguage("sum")
        );

        @Override
        public void action() {
            ACLMessage msg = myAgent.receive(template);

            if (msg != null) {
                try {
                    String content = msg.getContent();
                    String[] numbers = content.split(",");

                    if (numbers.length == 2) {
                        int A = Integer.parseInt(numbers[0].trim());
                        int B = Integer.parseInt(numbers[1].trim());

                        long sum = calculateSum(A, B);

                        ACLMessage reply = msg.createReply();
                        reply.setPerformative(ACLMessage.CONFIRM);
                        reply.setContent(String.valueOf(sum));
                        send(reply);

                        System.out.println(getLocalName() + ": вычислил сумму от " + A + " до " + B + " = " + sum);
                    } else {
                        sendErrorReply(msg, "Неверный формат данных. Ожидается: число,число");
                    }

                } catch (NumberFormatException e) {
                    sendErrorReply(msg, "Ошибка преобразования чисел");
                }
            } else {
                block();
            }
        }

        private long calculateSum(int A, int B) {
            int n = Math.abs(B - A) + 1;
            return (long) n * (A + B) / 2;
        }

        private void sendErrorReply(ACLMessage msg, String error) {
            ACLMessage reply = msg.createReply();
            reply.setPerformative(ACLMessage.FAILURE);
            reply.setContent(error);
            send(reply);
            System.out.println(getLocalName() + ": ошибка - " + error);
        }
    }
}