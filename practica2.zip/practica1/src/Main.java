import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;
import jade.wrapper.StaleProxyException;

public class Main {
    public static void main(String[] args) {
        Runtime rt = Runtime.instance();
        Profile profile = new ProfileImpl();
        profile.setParameter(Profile.MAIN_HOST, "localhost");
        profile.setParameter(Profile.MAIN_PORT, "1099");
        profile.setParameter(Profile.GUI, "true");

        AgentContainer mainContainer = rt.createMainContainer(profile);

        try {
            String[] calculatorNames = {"Calculator1", "Calculator2", "Calculator3"};
            for (String name : calculatorNames) {
                AgentController calculator = mainContainer.createNewAgent(
                        name,
                        "CalculatorAgent",
                        new Object[]{}
                );
                calculator.start();
            }
            
            String calculatorsList = String.join(",", calculatorNames);
            AgentController coordinator = mainContainer.createNewAgent(
                    "Coordinator",
                    "CoordinatorAgent",
                    new Object[]{calculatorsList}
            );
            coordinator.start();

            System.out.println("Все агенты запущены!");
            System.out.println("Вычислители: " + calculatorsList);
            System.out.println("Координатор: Coordinator");

        } catch (StaleProxyException e) {
            e.printStackTrace();
        }
    }
}