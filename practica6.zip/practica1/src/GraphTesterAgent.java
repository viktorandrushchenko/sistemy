import jade.core.Agent;
import jade.core.AID;
import jade.core.behaviours.OneShotBehaviour;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import java.util.*;

public class GraphTesterAgent extends Agent {
    private Map<String, TestResult> testResults = new HashMap<>();

    @Override
    protected void setup() {
        System.out.println("Тестер графов запущен");

        addBehaviour(new OneShotBehaviour() {
            @Override
            public void action() {
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                testRoute("Node1", "Node5");
                testRoute("Node1", "Node4");
                testRoute("Node2", "Node6");
                testRoute("Node1", "Node10");
            }
        });

        addBehaviour(new ResponseBehaviour());
    }

    private void testRoute(String fromNode, String toNode) {
        String testId = "test_" + fromNode + "_to_" + toNode + "_" + System.currentTimeMillis();
        testResults.put(testId, new TestResult(fromNode, toNode));

        System.out.println("\n=== ТЕСТ: " + fromNode + " → " + toNode + " ===");

        ACLMessage request = new ACLMessage(ACLMessage.REQUEST);
        request.addReceiver(new AID(fromNode, AID.ISLOCALNAME));
        request.setContent(toNode);
        request.setConversationId(testId);
        send(request);

        System.out.println("Запрос отправлен к агенту " + fromNode);
    }

    private class ResponseBehaviour extends CyclicBehaviour {
        @Override
        public void action() {
            ACLMessage confirmMsg = myAgent.receive(MessageTemplate.MatchPerformative(ACLMessage.CONFIRM));
            if (confirmMsg != null) {
                String testId = confirmMsg.getConversationId();
                TestResult result = testResults.get(testId);

                if (result != null) {
                    result.success = true;
                    result.path = confirmMsg.getContent();

                    System.out.println("МАРШРУТ НАЙДЕН для " + result.from + " → " + result.to);
                    String[] pathNodes = result.path.split("\n");
                    System.out.print("Путь: ");
                    for (int i = 0; i < pathNodes.length; i++) {
                        System.out.print(pathNodes[i] + (i < pathNodes.length - 1 ? " → " : ""));
                    }
                    System.out.println("\n---");
                }
                return;
            }

            ACLMessage disconfirmMsg = myAgent.receive(MessageTemplate.MatchPerformative(ACLMessage.DISCONFIRM));
            if (disconfirmMsg != null) {
                String testId = disconfirmMsg.getConversationId();
                TestResult result = testResults.get(testId);

                if (result != null) {
                    result.success = false;
                    System.out.println("МАРШРУТ НЕ НАЙДЕН для " + result.from + " → " + result.to);
                    System.out.println("---");
                }
                return;
            }

            block();
        }
    }

    private static class TestResult {
        String from;
        String to;
        boolean success;
        String path;

        TestResult(String from, String to) {
            this.from = from;
            this.to = to;
        }
    }
}
