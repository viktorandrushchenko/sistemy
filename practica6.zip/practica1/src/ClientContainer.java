import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;

public class ClientContainer {
    public static void main(String[] args) {
        Runtime rt = Runtime.instance();
        Profile profile = new ProfileImpl();
        profile.setParameter(Profile.MAIN_HOST, "localhost");
        profile.setParameter(Profile.MAIN_PORT, "1099");

        AgentContainer clientContainer = rt.createAgentContainer(profile);

        System.out.println("Клиентский контейнер подключен к главному");

        try {
            Thread.sleep(2000);

            AgentController coordinator1 = clientContainer.createNewAgent(
                    "Coordinator1", "CoordinatorAgent", new Object[]{"Calculator1,Calculator2"});
            AgentController coordinator2 = clientContainer.createNewAgent(
                    "Coordinator2", "CoordinatorAgent", new Object[]{"Calculator1,Calculator2"});

            coordinator1.start();
            coordinator2.start();

            Thread.sleep(2000);

            AgentController customer = clientContainer.createNewAgent(
                    "Customer", "CustomerAgent", new Object[]{});
            customer.start();

            System.out.println("Координаторы и заказчик запущены в клиентском контейнере");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}