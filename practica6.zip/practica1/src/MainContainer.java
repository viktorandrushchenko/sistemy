import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;

public class MainContainer {
    public static void main(String[] args) {
        Runtime rt = Runtime.instance();
        Profile profile = new ProfileImpl();
        profile.setParameter(Profile.MAIN_HOST, "localhost");
        profile.setParameter(Profile.MAIN_PORT, "1099");
        profile.setParameter(Profile.GUI, "true");

        AgentContainer mainContainer = rt.createMainContainer(profile);

        System.out.println("Главный контейнер запущен на localhost:1099");

        try {
            Thread.sleep(3000);

            AgentController calculator1 = mainContainer.createNewAgent(
                    "Calculator1", "EnhancedCalculatorAgent", new Object[]{});
            AgentController calculator2 = mainContainer.createNewAgent(
                    "Calculator2", "EnhancedCalculatorAgent", new Object[]{});

            calculator1.start();
            calculator2.start();

            System.out.println("Калькуляторы запущены в главном контейнере");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
