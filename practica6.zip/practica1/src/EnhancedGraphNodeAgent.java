import jade.core.Agent;
import jade.core.AID;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import java.util.*;

public class EnhancedGraphNodeAgent extends Agent {
    private Set<String> neighbors;
    private Map<String, RouteRequest> pendingRequests;
    private Set<String> processedRequests;

    @Override
    protected void setup() {
        Object[] args = getArguments();
        neighbors = new HashSet<>();

        if (args != null && args.length > 0) {
            String[] neighborNames = args[0].toString().split(",");
            for (String name : neighborNames) {
                neighbors.add(name.trim());
            }
        }

        pendingRequests = new HashMap<>();
        processedRequests = new HashSet<>();

        addBehaviour(new RouteRequestBehaviour());
        addBehaviour(new RouteResponseBehaviour());

        System.out.println("Узел " + getLocalName() + " запущен. Соседи: " + neighbors);
    }

    private class RouteRequestBehaviour extends CyclicBehaviour {
        private MessageTemplate template = MessageTemplate.MatchPerformative(ACLMessage.REQUEST);

        @Override
        public void action() {
            ACLMessage msg = myAgent.receive(template);

            if (msg != null) {
                String targetNode = msg.getContent();
                String requestId = msg.getConversationId();
                String sender = msg.getSender().getLocalName();

                if (processedRequests.contains(requestId)) {
                    return;
                }
                processedRequests.add(requestId);

                List<String> currentPath = extractPathFromMessage(msg);
                if (currentPath == null) {
                    currentPath = new ArrayList<>();
                }
                currentPath.add(getLocalName());

                System.out.println(getLocalName() + ": запрос " + requestId + " от " + sender +
                        " к " + targetNode + " путь: " + currentPath);

                if (getLocalName().equals(targetNode)) {
                    ACLMessage reply = msg.createReply();
                    reply.setPerformative(ACLMessage.CONFIRM);
                    reply.setContent(String.join("\n", currentPath));
                    reply.setConversationId(requestId);
                    send(reply);
                    System.out.println(getLocalName() + ": цель достигнута!");
                } else {
                    pendingRequests.put(requestId, new RouteRequest(msg.getSender(), targetNode, currentPath));
                    boolean forwarded = forwardToNeighbors(requestId, targetNode, currentPath);

                    if (!forwarded) {
                        ACLMessage reply = msg.createReply();
                        reply.setPerformative(ACLMessage.DISCONFIRM);
                        reply.setConversationId(requestId);
                        send(reply);
                        pendingRequests.remove(requestId);
                        System.out.println(getLocalName() + ": маршрут не найден");
                    }
                }
            } else {
                block();
            }
        }

        private List<String> extractPathFromMessage(ACLMessage msg) {
            String pathInfo = msg.getUserDefinedParameter("path");
            if (pathInfo != null && !pathInfo.isEmpty()) {
                return new ArrayList<>(Arrays.asList(pathInfo.split(",")));
            }
            return new ArrayList<>();
        }

        private boolean forwardToNeighbors(String requestId, String targetNode, List<String> path) {
            boolean forwarded = false;

            for (String neighbor : neighbors) {
                if (!path.contains(neighbor)) {
                    ACLMessage forwardMsg = new ACLMessage(ACLMessage.REQUEST);
                    forwardMsg.addReceiver(new AID(neighbor, AID.ISLOCALNAME));
                    forwardMsg.setContent(targetNode);
                    forwardMsg.setConversationId(requestId);
                    forwardMsg.addUserDefinedParameter("path", String.join(",", path));
                    send(forwardMsg);
                    forwarded = true;

                    System.out.println(getLocalName() + ": переслал запрос " + requestId + " к " + neighbor);
                }
            }

            return forwarded;
        }
    }

    private class RouteResponseBehaviour extends CyclicBehaviour {
        private MessageTemplate confirmTemplate = MessageTemplate.MatchPerformative(ACLMessage.CONFIRM);
        private MessageTemplate disconfirmTemplate = MessageTemplate.MatchPerformative(ACLMessage.DISCONFIRM);

        @Override
        public void action() {
            ACLMessage confirmMsg = myAgent.receive(confirmTemplate);
            if (confirmMsg != null) {
                processConfirm(confirmMsg);
                return;
            }

            ACLMessage disconfirmMsg = myAgent.receive(disconfirmTemplate);
            if (disconfirmMsg != null) {
                processDisconfirm(disconfirmMsg);
                return;
            }

            block();
        }

        private void processConfirm(ACLMessage msg) {
            String requestId = msg.getConversationId();
            RouteRequest request = pendingRequests.get(requestId);

            if (request != null) {
                String foundPath = msg.getContent();

                if (request.originalSender != null) {
                    ACLMessage reply = new ACLMessage(ACLMessage.CONFIRM);
                    reply.addReceiver(request.originalSender);
                    reply.setContent(foundPath);
                    reply.setConversationId(requestId);
                    send(reply);

                    System.out.println(getLocalName() + ": отправил найденный маршрут клиенту: " + foundPath);
                }

                pendingRequests.remove(requestId);
            }
        }

        private void processDisconfirm(ACLMessage msg) {
            String requestId = msg.getConversationId();

            boolean allResponsesReceived = checkAllResponsesReceived(requestId);

            if (allResponsesReceived) {
                RouteRequest request = pendingRequests.get(requestId);
                if (request != null && request.originalSender != null) {
                    ACLMessage reply = new ACLMessage(ACLMessage.DISCONFIRM);
                    reply.addReceiver(request.originalSender);
                    reply.setConversationId(requestId);
                    send(reply);

                    System.out.println(getLocalName() + ": все соседи сообщили, что маршрут не найден");
                }
                pendingRequests.remove(requestId);
            }
        }

        private boolean checkAllResponsesReceived(String requestId) {
            return true;
        }
    }

    private static class RouteRequest {
        AID originalSender;
        String targetNode;
        List<String> path;

        RouteRequest(AID originalSender, String targetNode, List<String> path) {
            this.originalSender = originalSender;
            this.targetNode = targetNode;
            this.path = new ArrayList<>(path);
        }
    }
}