import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;

public class CyclicGraphMain {
    public static void main(String[] args) {
        Runtime rt = Runtime.instance();
        Profile profile = new ProfileImpl();
        profile.setParameter(Profile.MAIN_HOST, "localhost");
        profile.setParameter(Profile.MAIN_PORT, "1099");
        profile.setParameter(Profile.GUI, "true");

        AgentContainer mainContainer = rt.createMainContainer(profile);

        try {
            System.out.println("Создаем циклический граф...");

            AgentController node1 = mainContainer.createNewAgent(
                    "Node1", "EnhancedGraphNodeAgent", new Object[]{"Node2,Node3"});
            AgentController node2 = mainContainer.createNewAgent(
                    "Node2", "EnhancedGraphNodeAgent", new Object[]{"Node1,Node3"});
            AgentController node3 = mainContainer.createNewAgent(
                    "Node3", "EnhancedGraphNodeAgent", new Object[]{"Node1,Node2,Node6"});
            AgentController node4 = mainContainer.createNewAgent(
                    "Node4", "EnhancedGraphNodeAgent", new Object[]{"Node5,Node6"});
            AgentController node5 = mainContainer.createNewAgent(
                    "Node5", "EnhancedGraphNodeAgent", new Object[]{"Node4,Node6"});
            AgentController node6 = mainContainer.createNewAgent(
                    "Node6", "EnhancedGraphNodeAgent", new Object[]{"Node3,Node4,Node5"});

            node1.start();
            node2.start();
            node3.start();
            node4.start();
            node5.start();
            node6.start();

            Thread.sleep(3000);

            System.out.println("Запускаем тестер...");
            AgentController tester = mainContainer.createNewAgent(
                    "GraphTester", "GraphTesterAgent", new Object[]{});
            tester.start();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}