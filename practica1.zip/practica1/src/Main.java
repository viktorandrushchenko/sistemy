import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;
import jade.wrapper.StaleProxyException;

public class Main {
    public static void main(String[] args) {

        Runtime rt = Runtime.instance();

        Profile profile = new ProfileImpl();
        profile.setParameter(Profile.MAIN_HOST, "localhost");
        profile.setParameter(Profile.MAIN_PORT, "1099");
        profile.setParameter(Profile.GUI, "true");


        AgentContainer mainContainer = rt.createMainContainer(profile);

        System.out.println("запущен");

        try {
            AgentController dummy1 = mainContainer.createNewAgent(
                    "Dummy1",
                    "jade.tools.DummyAgent.DummyAgent",
                    new Object[]{}
            );

            AgentController ac = mainContainer.createNewAgent(
                    "SimpleAgent",
                    "SimpleAgent",
                    new Object[]{}
            );
            ac.start();

        } catch (StaleProxyException e) {
            e.printStackTrace();
        }

    }
}
