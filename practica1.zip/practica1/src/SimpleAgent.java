import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import java.util.logging.Logger;

public class SimpleAgent extends Agent {

    @Override
    protected void setup() {
        System.out.println("Агент " + getLocalName() + " готов к приему сообщений!");

        addBehaviour(new MessageReadingBehaviour());
    }

    private class MessageReadingBehaviour extends CyclicBehaviour {
        private Logger logger = Logger.getLogger(getClass().getName());

        @Override
        public void action() {
            ACLMessage msg = myAgent.receive();

            if (msg != null) {
                logger.info("=== ПОЛУЧЕНО СООБЩЕНИЕ ===");
                logger.info("Отправитель: " + msg.getSender().getLocalName());
                logger.info("Коммуникативный акт: " + msg.getPerformative());
                logger.info("Содержимое: " + msg.getContent());
                logger.info("Язык: " + msg.getLanguage());
                logger.info("=== КОНЕЦ СООБЩЕНИЯ ===");

                if (!msg.getSender().getLocalName().startsWith("ams")) {
                    ACLMessage reply = msg.createReply();
                    reply.setPerformative(ACLMessage.INFORM);
                    reply.setContent("Сообщение получено агентом " + getLocalName());
                    send(reply);
                }
            } else {
                block();
            }
        }
    }
}
