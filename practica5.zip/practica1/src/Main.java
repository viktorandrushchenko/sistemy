import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;

public class Main {
    public static void main(String[] args) {
        Runtime rt = Runtime.instance();
        Profile profile = new ProfileImpl();
        profile.setParameter(Profile.MAIN_HOST, "localhost");
        profile.setParameter(Profile.MAIN_PORT, "1099");
        profile.setParameter(Profile.GUI, "true");

        AgentContainer mainContainer = rt.createMainContainer(profile);

        try {
            Thread.sleep(1000);

            AgentController calculator1 = mainContainer.createNewAgent(
                    "Calculator1", "EnhancedCalculatorAgent", new Object[]{});
            AgentController calculator2 = mainContainer.createNewAgent(
                    "Calculator2", "EnhancedCalculatorAgent", new Object[]{});
            AgentController calculator3 = mainContainer.createNewAgent(
                    "Calculator3", "EnhancedCalculatorAgent", new Object[]{});

            calculator1.start();
            calculator2.start();
            calculator3.start();

            Thread.sleep(2000);

            AgentController coordinator1 = mainContainer.createNewAgent(
                    "Coordinator1", "CoordinatorAgent", new Object[]{"Calculator1,Calculator2,Calculator3"});
            AgentController coordinator2 = mainContainer.createNewAgent(
                    "Coordinator2", "CoordinatorAgent", new Object[]{"Calculator1,Calculator2"});
            AgentController coordinator3 = mainContainer.createNewAgent(
                    "Coordinator3", "CoordinatorAgent", new Object[]{"Calculator2,Calculator3"});

            coordinator1.start();
            coordinator2.start();
            coordinator3.start();

            Thread.sleep(3000);

            AgentController customer = mainContainer.createNewAgent(
                    "Customer", "CustomerAgent", new Object[]{});
            customer.start();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}