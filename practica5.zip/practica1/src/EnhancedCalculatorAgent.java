import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.domain.FIPAException;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import java.util.Random;
import java.util.concurrent.*;

public class EnhancedCalculatorAgent extends Agent {
    private ExecutorService executor;
    private Random random = new Random();
    private int calculationsCompleted = 0;

    @Override
    protected void setup() {
        executor = Executors.newFixedThreadPool(3);

        DFAgentDescription dfd = new DFAgentDescription();
        dfd.setName(getAID());
        ServiceDescription sd = new ServiceDescription();
        sd.setType("calculator");
        sd.setName("sum-calculator");
        sd.addLanguages("sum");
        dfd.addServices(sd);

        try {
            DFService.register(this, dfd);
        } catch (FIPAException e) {
            e.printStackTrace();
        }

        addBehaviour(new CalculationBehaviour());
        addBehaviour(new StatusBehaviour());

        System.out.println("Улучшенный калькулятор " + getLocalName() + " запущен");
    }

    @Override
    protected void takeDown() {
        executor.shutdown();
        try {
            DFService.deregister(this);
        } catch (FIPAException e) {
            e.printStackTrace();
        }
    }

    private class CalculationBehaviour extends CyclicBehaviour {
        private MessageTemplate template = MessageTemplate.and(
                MessageTemplate.MatchPerformative(ACLMessage.REQUEST),
                MessageTemplate.MatchLanguage("sum")
        );

        @Override
        public void action() {
            ACLMessage request = myAgent.receive(template);
            if (request != null) {
                executor.submit(new CalculationTask(request));
            } else {
                block();
            }
        }
    }

    private class CalculationTask implements Runnable {
        private final ACLMessage request;

        public CalculationTask(ACLMessage request) {
            this.request = request;
        }

        @Override
        public void run() {
            try {
                String content = request.getContent();
                String[] numbers = content.split(",");

                if (numbers.length == 2) {
                    int A = Integer.parseInt(numbers[0].trim());
                    int B = Integer.parseInt(numbers[1].trim());

                    Thread.sleep(1000 + random.nextInt(2000));

                    long result = calculateSum(A, B);

                    ACLMessage reply = request.createReply();
                    reply.setPerformative(ACLMessage.INFORM);
                    reply.setContent(String.valueOf(result));
                    send(reply);

                    calculationsCompleted++;

                } else {
                    ACLMessage reply = request.createReply();
                    reply.setPerformative(ACLMessage.FAILURE);
                    reply.setContent("Invalid format");
                    send(reply);
                }

            } catch (Exception e) {
                ACLMessage reply = request.createReply();
                reply.setPerformative(ACLMessage.FAILURE);
                reply.setContent("Calculation error: " + e.getMessage());
                send(reply);
            }
        }

        private long calculateSum(int A, int B) {
            int n = Math.abs(B - A) + 1;
            return (long) n * (A + B) / 2;
        }
    }

    private class StatusBehaviour extends CyclicBehaviour {
        private long lastReport = 0;
        private static final long REPORT_INTERVAL = 20000;

        @Override
        public void action() {
            long currentTime = System.currentTimeMillis();
            if (currentTime - lastReport > REPORT_INTERVAL) {
                System.out.println("Калькулятор " + getLocalName() + ": выполнено " + calculationsCompleted + " вычислений");
                lastReport = currentTime;
            }

            block(1000);
        }
    }
}