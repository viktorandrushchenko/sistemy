import jade.core.Agent;
import jade.core.behaviours.FSMBehaviour;
import jade.core.behaviours.OneShotBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.domain.FIPAException;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import java.util.concurrent.*;

public class ThreadedCalculatorAgent extends Agent {
    private static final String STATE_WAITING = "waiting";
    private static final String STATE_BUSY = "busy";

    private ExecutorService executor;
    private int activeCalculations = 0;
    private final int MAX_PARALLEL_CALCULATIONS = 3;

    @Override
    protected void setup() {
        executor = Executors.newFixedThreadPool(MAX_PARALLEL_CALCULATIONS);

        DFAgentDescription dfd = new DFAgentDescription();
        dfd.setName(getAID());
        ServiceDescription sd = new ServiceDescription();
        sd.setType("calculator");
        sd.setName("sum-calculator");
        sd.addLanguages("sum");
        dfd.addServices(sd);

        try {
            DFService.register(this, dfd);
        } catch (FIPAException e) {
            e.printStackTrace();
        }

        FSMBehaviour fsm = new FSMBehaviour(this);

        fsm.registerFirstState(new WaitingState(), STATE_WAITING);
        fsm.registerState(new BusyState(), STATE_BUSY);

        fsm.registerDefaultTransition(STATE_WAITING, STATE_BUSY);
        fsm.registerTransition(STATE_BUSY, STATE_WAITING, 0);
        fsm.registerTransition(STATE_BUSY, STATE_BUSY, 1);

        addBehaviour(fsm);
    }

    @Override
    protected void takeDown() {
        executor.shutdown();
        try {
            DFService.deregister(this);
        } catch (FIPAException e) {
            e.printStackTrace();
        }
    }

    private class WaitingState extends OneShotBehaviour {
        private MessageTemplate template = MessageTemplate.and(
                MessageTemplate.MatchPerformative(ACLMessage.REQUEST),
                MessageTemplate.MatchLanguage("sum")
        );

        @Override
        public void action() {
            ACLMessage request = myAgent.receive(template);
            if (request != null && activeCalculations < MAX_PARALLEL_CALCULATIONS) {
                activeCalculations++;
                executor.submit(new CalculationTask(request));
                System.out.println(getLocalName() + ": запущено вычисление (" + activeCalculations + " активных)");
            } else if (request != null) {
                sendRefuse(request);
            }
        }

        @Override
        public int onEnd() {
            return activeCalculations > 0 ? 1 : 0;
        }
    }

    private class BusyState extends OneShotBehaviour {
        private MessageTemplate template = MessageTemplate.and(
                MessageTemplate.MatchPerformative(ACLMessage.REQUEST),
                MessageTemplate.MatchLanguage("sum")
        );

        @Override
        public void action() {
            ACLMessage request = myAgent.receive(template);
            if (request != null) {
                if (activeCalculations < MAX_PARALLEL_CALCULATIONS) {
                    activeCalculations++;
                    executor.submit(new CalculationTask(request));
                    System.out.println(getLocalName() + ": запущено новое вычисление (" + activeCalculations + " активных)");
                } else {
                    sendRefuse(request);
                }
            }
        }

        @Override
        public int onEnd() {
            return activeCalculations > 0 ? 1 : 0;
        }
    }

    private void sendRefuse(ACLMessage request) {
        ACLMessage refuse = request.createReply();
        refuse.setPerformative(ACLMessage.REFUSE);
        refuse.setContent("Calculator is busy");
        send(refuse);
        System.out.println(getLocalName() + ": отправлен REFUSE - занят");
    }

    private class CalculationTask implements Runnable {
        private final ACLMessage request;

        public CalculationTask(ACLMessage request) {
            this.request = request;
        }

        @Override
        public void run() {
            try {
                String content = request.getContent();
                String[] numbers = content.split(",");

                if (numbers.length == 2) {
                    int A = Integer.parseInt(numbers[0].trim());
                    int B = Integer.parseInt(numbers[1].trim());

                    long result = calculateSum(A, B);

                    ACLMessage reply = request.createReply();
                    reply.setPerformative(ACLMessage.CONFIRM);
                    reply.setContent(String.valueOf(result));
                    send(reply);

                    System.out.println(getLocalName() + ": вычисление завершено в потоке " + Thread.currentThread().getName());
                }
            } catch (NumberFormatException e) {
                ACLMessage reply = request.createReply();
                reply.setPerformative(ACLMessage.FAILURE);
                reply.setContent("Number parsing error");
                send(reply);
            } finally {
                activeCalculations--;
            }
        }

        private long calculateSum(int A, int B) {
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            int n = Math.abs(B - A) + 1;
            return (long) n * (A + B) / 2;
        }
    }
}