import jade.core.Agent;
import jade.core.AID;
import jade.core.behaviours.Behaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.proto.ContractNetInitiator;
import java.util.Vector;
import java.util.Date;
import java.util.Random;

public class CustomerAgent extends Agent {
    private int calculationRequests = 0;
    private int successfulCalculations = 0;

    @Override
    protected void setup() {
        System.out.println("Заказчик " + getLocalName() + " запущен");

        addBehaviour(new CalculationSchedulerBehaviour());
    }

    private class CalculationSchedulerBehaviour extends Behaviour {
        private long lastRequestTime = 0;
        private static final long REQUEST_INTERVAL = 10000;

        @Override
        public void action() {
            long currentTime = System.currentTimeMillis();
            if (currentTime - lastRequestTime > REQUEST_INTERVAL) {
                sendCalculationCFP();
                lastRequestTime = currentTime;
                calculationRequests++;
            }
        }

        @Override
        public boolean done() {
            return calculationRequests >= 5;
        }

        @Override
        public int onEnd() {
            System.out.println("=== ИТОГИ РАБОТЫ ЗАКАЗЧИКА ===");
            System.out.println("Всего запросов: " + calculationRequests);
            System.out.println("Успешных вычислений: " + successfulCalculations);
            return super.onEnd();
        }
    }

    private void sendCalculationCFP() {
        Random rand = new Random();
        int A = rand.nextInt(50) + 1;
        int B = A + rand.nextInt(100) + 50;

        System.out.println("\n=== НОВЫЙ ЗАПРОС CFP ===");
        System.out.println("Сумма от " + A + " до " + B);

        ACLMessage cfp = new ACLMessage(ACLMessage.CFP);

        cfp.addReceiver(new AID("Coordinator1", AID.ISLOCALNAME));
        cfp.addReceiver(new AID("Coordinator2", AID.ISLOCALNAME));
        cfp.addReceiver(new AID("Coordinator3", AID.ISLOCALNAME));

        cfp.setContent(A + "," + B);
        cfp.setLanguage("sum");
        cfp.setProtocol("fipa-contract-net");
        cfp.setReplyByDate(new Date(System.currentTimeMillis() + 5000));

        addBehaviour(new ContractNetInitiator(this, cfp) {
            @Override
            protected Vector prepareCfps(ACLMessage cfp) {
                System.out.println("Отправлен CFP координаторам");
                return super.prepareCfps(cfp);
            }

            @Override
            protected void handlePropose(ACLMessage propose, Vector acceptances) {
                System.out.println("Получено предложение от " + propose.getSender().getLocalName() +
                        ": " + propose.getContent());
            }

            @Override
            protected void handleRefuse(ACLMessage refuse) {
                System.out.println("Отказ от " + refuse.getSender().getLocalName() +
                        ": " + refuse.getContent());
            }

            @Override
            protected void handleAllResponses(Vector responses, Vector acceptances) {
                ACLMessage bestProposal = null;
                double bestPrice = Double.MAX_VALUE;

                for (Object response : responses) {
                    ACLMessage msg = (ACLMessage) response;
                    if (msg.getPerformative() == ACLMessage.PROPOSE) {
                        try {
                            double price = Double.parseDouble(msg.getContent());
                            if (price < bestPrice) {
                                bestPrice = price;
                                bestProposal = msg;
                            }
                        } catch (NumberFormatException e) {
                            System.out.println("Некорректное предложение от " + msg.getSender().getLocalName());
                        }
                    }
                }

                if (bestProposal != null) {
                    ACLMessage accept = bestProposal.createReply();
                    accept.setPerformative(ACLMessage.ACCEPT_PROPOSAL);
                    accept.setContent("Выбран для выполнения");
                    acceptances.add(accept);
                    System.out.println("Выбран координатор: " + bestProposal.getSender().getLocalName() +
                            " с ценой " + bestPrice);
                } else {
                    System.out.println("Нет подходящих предложений");
                }
            }

            @Override
            protected void handleInform(ACLMessage inform) {
                successfulCalculations++;
                long result = Long.parseLong(inform.getContent());
                System.out.println("УСПЕШНОЕ ВЫЧИСЛЕНИЕ от " + inform.getSender().getLocalName() +
                        ": результат = " + result);
            }

            @Override
            protected void handleFailure(ACLMessage failure) {
                System.out.println("ОШИБКА ВЫЧИСЛЕНИЯ от " + failure.getSender().getLocalName() +
                        ": " + failure.getContent());
            }
        });
    }
}