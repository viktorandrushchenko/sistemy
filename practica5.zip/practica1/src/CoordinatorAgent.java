import jade.core.Agent;
import jade.core.AID;
import jade.core.behaviours.Behaviour;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.proto.ContractNetResponder;
import jade.proto.SSContractNetResponder;
import java.util.*;

public class CoordinatorAgent extends Agent {
    private AID[] calculators;
    private Random random = new Random();
    private int tasksCompleted = 0;
    private int tasksAccepted = 0;

    @Override
    protected void setup() {
        Object[] args = getArguments();
        if (args != null && args.length > 0) {
            String[] calculatorNames = args[0].toString().split(",");
            calculators = new AID[calculatorNames.length];
            for (int i = 0; i < calculatorNames.length; i++) {
                calculators[i] = new AID(calculatorNames[i].trim(), AID.ISLOCALNAME);
            }
        }

        System.out.println("Координатор " + getLocalName() + " запущен с " +
                calculators.length + " калькуляторами");

        MessageTemplate template = MessageTemplate.and(
                MessageTemplate.MatchProtocol("fipa-contract-net"),
                MessageTemplate.MatchPerformative(ACLMessage.CFP)
        );

        addBehaviour(new ContractNetResponder(this, template) {
            @Override
            protected ACLMessage handleCfp(ACLMessage cfp) {
                System.out.println(getLocalName() + ": получен CFP от " + cfp.getSender().getLocalName());

                String content = cfp.getContent();
                String[] numbers = content.split(",");

                if (numbers.length != 2) {
                    ACLMessage refuse = cfp.createReply();
                    refuse.setPerformative(ACLMessage.REFUSE);
                    refuse.setContent("Неверный формат данных");
                    return refuse;
                }

                try {
                    int A = Integer.parseInt(numbers[0]);
                    int B = Integer.parseInt(numbers[1]);

                    if (!canHandleRequest()) {
                        ACLMessage refuse = cfp.createReply();
                        refuse.setPerformative(ACLMessage.REFUSE);
                        refuse.setContent("Координатор перегружен");
                        return refuse;
                    }

                    double price = calculatePrice(A, B);
                    int time = estimateTime(A, B);

                    ACLMessage propose = cfp.createReply();
                    propose.setPerformative(ACLMessage.PROPOSE);
                    propose.setContent(String.valueOf(price));
                    propose.setReplyWith("propose-" + System.currentTimeMillis());

                    System.out.println(getLocalName() + ": отправлено предложение с ценой " + price);

                    return propose;

                } catch (NumberFormatException e) {
                    ACLMessage refuse = cfp.createReply();
                    refuse.setPerformative(ACLMessage.REFUSE);
                    refuse.setContent("Ошибка парсинга чисел");
                    return refuse;
                }
            }

            @Override
            protected ACLMessage handleAcceptProposal(ACLMessage cfp, ACLMessage propose, ACLMessage accept) {
                System.out.println(getLocalName() + ": предложение принято!");
                tasksAccepted++;

                String content = cfp.getContent();
                String[] numbers = content.split(",");
                int A = Integer.parseInt(numbers[0]);
                int B = Integer.parseInt(numbers[1]);

                ACLMessage result = executeCalculation(A, B, cfp.getSender());

                if (result.getPerformative() == ACLMessage.INFORM) {
                    tasksCompleted++;
                    System.out.println(getLocalName() + ": вычисление успешно завершено");
                }

                return result;
            }

            @Override
            protected void handleRejectProposal(ACLMessage cfp, ACLMessage propose, ACLMessage reject) {
                System.out.println(getLocalName() + ": предложение отклонено");
            }
        });

        addBehaviour(new StatusBehaviour());
    }

    private boolean canHandleRequest() {
        return random.nextDouble() > 0.3;
    }

    private double calculatePrice(int A, int B) {
        int range = Math.abs(B - A);
        double basePrice = range * 0.1;
        double margin = random.nextDouble() * 0.5;
        return basePrice * (1 + margin);
    }

    private int estimateTime(int A, int B) {
        int range = Math.abs(B - A);
        return range / 10 + random.nextInt(5);
    }

    private ACLMessage executeCalculation(int A, int B, AID customer) {
        try {
            if (calculators == null || calculators.length == 0) {
                throw new RuntimeException("Нет доступных калькуляторов");
            }

            long result = distributeCalculation(A, B);

            ACLMessage inform = new ACLMessage(ACLMessage.INFORM);
            inform.addReceiver(customer);
            inform.setContent(String.valueOf(result));
            inform.setProtocol("fipa-contract-net");

            return inform;

        } catch (Exception e) {
            ACLMessage failure = new ACLMessage(ACLMessage.FAILURE);
            failure.addReceiver(customer);
            failure.setContent("Ошибка вычисления: " + e.getMessage());
            failure.setProtocol("fipa-contract-net");
            return failure;
        }
    }

    private long distributeCalculation(int A, int B) throws InterruptedException {
        Thread.sleep(2000 + random.nextInt(3000));

        int totalNumbers = Math.abs(B - A) + 1;
        int numbersPerCalculator = totalNumbers / calculators.length;
        int remainder = totalNumbers % calculators.length;

        long totalSum = 0;
        int current = A;

        for (int i = 0; i < calculators.length; i++) {
            int numbersForThisCalculator = numbersPerCalculator;
            if (i < remainder) {
                numbersForThisCalculator++;
            }

            int end = (A <= B) ? current + numbersForThisCalculator - 1 : current - numbersForThisCalculator + 1;

            long partialSum = calculatePartialSum(current, end);
            totalSum += partialSum;

            current = (A <= B) ? end + 1 : end - 1;
        }

        return totalSum;
    }

    private long calculatePartialSum(int start, int end) {
        int n = Math.abs(end - start) + 1;
        return (long) n * (start + end) / 2;
    }

    private class StatusBehaviour extends Behaviour {
        private long lastReport = 0;
        private static final long REPORT_INTERVAL = 15000;

        @Override
        public void action() {
            long currentTime = System.currentTimeMillis();
            if (currentTime - lastReport > REPORT_INTERVAL) {
                System.out.println("\n=== СТАТУС КООРДИНАТОРА " + getLocalName() + " ===");
                System.out.println("Принято задач: " + tasksAccepted);
                System.out.println("Завершено задач: " + tasksCompleted);
                System.out.println("Доступных калькуляторов: " + calculators.length);
                lastReport = currentTime;
            }
        }

        @Override
        public boolean done() {
            return false;
        }
    }
}