import jade.core.Agent;
import jade.core.behaviours.FSMBehaviour;
import jade.core.behaviours.OneShotBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.domain.FIPAException;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;

public class CalculatorAgent extends Agent {
    private static final String STATE_WAITING = "waiting";
    private static final String STATE_CALCULATING = "calculating";

    private ACLMessage currentRequest;
    private long calculationResult;

    @Override
    protected void setup() {
        DFAgentDescription dfd = new DFAgentDescription();
        dfd.setName(getAID());
        ServiceDescription sd = new ServiceDescription();
        sd.setType("calculator");
        sd.setName("sum-calculator");
        sd.addLanguages("sum");
        dfd.addServices(sd);

        try {
            DFService.register(this, dfd);
        } catch (FIPAException e) {
            e.printStackTrace();
        }

        FSMBehaviour fsm = new FSMBehaviour(this);

        fsm.registerFirstState(new WaitingState(), STATE_WAITING);
        fsm.registerState(new CalculatingState(), STATE_CALCULATING);

        fsm.registerDefaultTransition(STATE_WAITING, STATE_CALCULATING);
        fsm.registerDefaultTransition(STATE_CALCULATING, STATE_WAITING);

        addBehaviour(fsm);
    }

    @Override
    protected void takeDown() {
        try {
            DFService.deregister(this);
        } catch (FIPAException e) {
            e.printStackTrace();
        }
    }

    private class WaitingState extends OneShotBehaviour {
        private MessageTemplate template = MessageTemplate.and(
                MessageTemplate.MatchPerformative(ACLMessage.REQUEST),
                MessageTemplate.MatchLanguage("sum")
        );

        @Override
        public void action() {
            currentRequest = myAgent.receive(template);
            if (currentRequest != null) {
                System.out.println(getLocalName() + ": получен запрос, переходим в вычисление");
            }
        }

        @Override
        public int onEnd() {
            return currentRequest != null ? 1 : 0;
        }
    }

    private class CalculatingState extends OneShotBehaviour {
        @Override
        public void action() {
            if (currentRequest != null) {
                try {
                    String content = currentRequest.getContent();
                    String[] numbers = content.split(",");

                    if (numbers.length == 2) {
                        int A = Integer.parseInt(numbers[0].trim());
                        int B = Integer.parseInt(numbers[1].trim());

                        calculationResult = calculateSum(A, B);

                        ACLMessage reply = currentRequest.createReply();
                        reply.setPerformative(ACLMessage.CONFIRM);
                        reply.setContent(String.valueOf(calculationResult));
                        send(reply);

                        System.out.println(getLocalName() + ": вычисление завершено, результат: " + calculationResult);
                    }
                } catch (NumberFormatException e) {
                    ACLMessage reply = currentRequest.createReply();
                    reply.setPerformative(ACLMessage.FAILURE);
                    reply.setContent("Number parsing error");
                    send(reply);
                }

                currentRequest = null;
            }
        }

        private long calculateSum(int A, int B) {
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            int n = Math.abs(B - A) + 1;
            return (long) n * (A + B) / 2;
        }
    }
}