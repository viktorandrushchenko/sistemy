package smarthome;

import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;

public class SimpleLightAgent extends Agent {
    private String room;
    private String lightId;
    private boolean isOn = false;
    private int brightness = 0;
    private double powerConsumption = 0.0;

    protected void setup() {
        Object[] args = getArguments();
        room = (String) args[0];
        lightId = (String) args[1];

        System.out.println("Лампа " + getLocalName() + " (" + lightId + ") создана в " + room);

        addBehaviour(new LightControlBehaviour());
        addBehaviour(new PowerReportBehaviour());
    }

    private class LightControlBehaviour extends CyclicBehaviour {
        public void action() {
            ACLMessage msg = receive(MessageTemplate.MatchPerformative(ACLMessage.REQUEST));
            if (msg != null) {
                handleRequest(msg);
            } else {
                block();
            }
        }

        private void handleRequest(ACLMessage msg) {
            String content = msg.getContent();
            ACLMessage reply = msg.createReply();

            if (content.equals("turn-on")) {
                turnOn();
                reply.setPerformative(ACLMessage.CONFIRM);
                reply.setContent("ON:" + brightness + "%");
            } else if (content.equals("turn-off")) {
                turnOff();
                reply.setPerformative(ACLMessage.CONFIRM);
                reply.setContent("OFF");
            } else if (content.startsWith("brightness=")) {
                int newBrightness = Integer.parseInt(content.substring(11));
                setBrightness(newBrightness);
                reply.setPerformative(ACLMessage.CONFIRM);
                reply.setContent("Brightness:" + brightness + "%");
            } else if (content.equals("get-status")) {
                reply.setPerformative(ACLMessage.INFORM);
                reply.setContent(getStatus());
            } else {
                reply.setPerformative(ACLMessage.NOT_UNDERSTOOD);
                reply.setContent("Unknown command");
            }

            send(reply);
        }
    }

    private class PowerReportBehaviour extends CyclicBehaviour {
        private long lastReport = 0;

        public void action() {
            long currentTime = System.currentTimeMillis();
            if (currentTime - lastReport > 10000) {
                if (isOn) {
                    ACLMessage report = new ACLMessage(ACLMessage.INFORM);
                    report.addReceiver(new jade.core.AID("EnergyManager", jade.core.AID.ISLOCALNAME));
                    report.setContent("consumption:" + getLocalName() + ":" + powerConsumption);
                    send(report);
                }
                lastReport = currentTime;
            }
            block(5000);
        }
    }

    private void turnOn() {
        if (!isOn) {
            isOn = true;
            if (brightness == 0) brightness = 80;
            updatePower();
            System.out.println(getLocalName() + ": включена");
        }
    }

    private void turnOff() {
        if (isOn) {
            isOn = false;
            brightness = 0;
            powerConsumption = 0.0;
            System.out.println(getLocalName() + ": выключена");
        }
    }

    private void setBrightness(int value) {
        if (value < 0) value = 0;
        if (value > 100) value = 100;

        brightness = value;
        if (brightness == 0) {
            isOn = false;
        } else {
            isOn = true;
        }

        updatePower();
        System.out.println(getLocalName() + ": яркость " + brightness + "%");
    }

    private void updatePower() {
        powerConsumption = 60.0 * brightness / 100.0;
    }

    private String getStatus() {
        return String.format("%s: %s, %d%%, %.1fW in %s",
                lightId, isOn ? "ON" : "OFF", brightness, powerConsumption, room);
    }
}
