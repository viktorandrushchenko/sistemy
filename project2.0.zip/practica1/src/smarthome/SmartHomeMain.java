package smarthome;

import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;

public class SmartHomeMain {
    public static void main(String[] args) throws Exception {
        Runtime rt = Runtime.instance();
        Profile profile = new ProfileImpl();
        profile.setParameter(Profile.MAIN_HOST, "localhost");
        profile.setParameter(Profile.MAIN_PORT, "1099");
        profile.setParameter(Profile.GUI, "true");

        AgentContainer mainContainer = rt.createMainContainer(profile);

        System.out.println("ЗАПУСК СИСТЕМЫ УМНОГО ДОМА");
        System.out.println("=============================");

        Thread.sleep(2000);

        System.out.println("\n1. СОЗДАНИЕ СИСТЕМЫ ОСВЕЩЕНИЯ");
        System.out.println("=============================");

        String[] livingRoomLights = {"LR-Ceiling", "LR-Wall1", "LR-Wall2", "LR-Reading"};
        String[] bedroomLights = {"BR-Ceiling", "BR-Bedside1", "BR-Bedside2"};
        String[] kitchenLights = {"KT-Ceiling", "KT-Counter"};

        AgentController livingRoom = mainContainer.createNewAgent(
                "LightController-LivingRoom", "smarthome.EnhancedLightAgent",
                new Object[]{livingRoomLights, "Гостиная"});

        AgentController bedroom = mainContainer.createNewAgent(
                "LightController-Bedroom", "smarthome.EnhancedLightAgent",
                new Object[]{bedroomLights, "Спальня"});

        AgentController kitchen = mainContainer.createNewAgent(
                "LightController-Kitchen", "smarthome.EnhancedLightAgent",
                new Object[]{kitchenLights, "Кухня"});

        livingRoom.start();
        Thread.sleep(1000);

        bedroom.start();
        Thread.sleep(1000);

        kitchen.start();
        Thread.sleep(3000);

        System.out.println("\n2. ЗАПУСК СИСТЕМЫ УПРАВЛЕНИЯ ЭНЕРГИЕЙ");
        System.out.println("======================================");

        AgentController energyManager = mainContainer.createNewAgent(
                "EnergyManager", "smarthome.EnhancedEnergyManager", null);
        energyManager.start();

        Thread.sleep(5000);

        System.out.println("\n3. ЗАПУСК ТЕСТОВОГО СЦЕНАРИЯ");
        System.out.println("============================");

        AgentController tester = mainContainer.createNewAgent(
                "QuickTest", "smarthome.QuickTestAgent", null);
        tester.start();

        System.out.println("\nСИСТЕМА УСПЕШНО ЗАПУЩЕНА!");
        System.out.println("=============================");
        System.out.println("Доступные контроллеры:");
        System.out.println("  - LightController-LivingRoom (Гостиная)");
        System.out.println("  - LightController-Bedroom (Спальня)");
        System.out.println("  - LightController-Kitchen (Кухня)");
        System.out.println("  - EnergyManager (Управление энергией)");
        System.out.println("  - SystemTester (Тестирование)");
    }
}