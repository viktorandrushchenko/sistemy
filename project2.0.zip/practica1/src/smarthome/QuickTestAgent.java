package smarthome;

import jade.core.Agent;
import jade.core.AID;
import jade.core.behaviours.OneShotBehaviour;
import jade.lang.acl.ACLMessage;

public class QuickTestAgent extends Agent {
    protected void setup() {
        System.out.println("🔧 QuickTest запущен");

        addBehaviour(new OneShotBehaviour() {
            public void action() {
                System.out.println("\n=== РУЧНОЕ ТЕСТИРОВАНИЕ CONTRACT NET ===");


                System.out.println("1. Жду 8 секунд для инициализации...");
                try { Thread.sleep(8000); } catch (Exception e) {}


                System.out.println("2. Устанавливаю 100% яркость...");
                sendToAll("room-brightness=100");

                System.out.println("3. Жду 5 секунд для обновления потребления...");
                try { Thread.sleep(5000); } catch (Exception e) {}


                System.out.println("4. Проверяю статус EnergyManager...");
                ACLMessage statusRequest = new ACLMessage(ACLMessage.REQUEST);
                statusRequest.addReceiver(new AID("EnergyManager", AID.ISLOCALNAME));
                statusRequest.setContent("get-status");
                send(statusRequest);

                try { Thread.sleep(2000); } catch (Exception e) {}


                System.out.println("5. Запускаю Contract Net на 30%...");
                ACLMessage trigger = new ACLMessage(ACLMessage.REQUEST);
                trigger.addReceiver(new AID("EnergyManager", AID.ISLOCALNAME));
                trigger.setContent("initiate-contract-net:30");
                send(trigger);

                System.out.println("6. Ожидаю результаты аукциона 15 секунд...");
                System.out.println("=== Смотри логи EnergyManager ===");


                try { Thread.sleep(15000); } catch (Exception e) {}

                System.out.println("\n=== ТЕСТИРОВАНИЕ ЗАВЕРШЕНО ===");
            }

            private void sendToAll(String command) {
                String[] controllers = {
                        "LightController-LivingRoom",
                        "LightController-Bedroom",
                        "LightController-Kitchen"
                };

                for (String controller : controllers) {
                    ACLMessage msg = new ACLMessage(ACLMessage.REQUEST);
                    msg.addReceiver(new AID(controller, AID.ISLOCALNAME));
                    msg.setContent(command);
                    send(msg);
                }
            }
        });
    }
}