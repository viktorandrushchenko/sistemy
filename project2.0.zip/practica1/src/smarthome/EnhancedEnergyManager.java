package smarthome;

import jade.core.Agent;
import jade.core.AID;
import jade.core.behaviours.*;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.*;
import jade.domain.FIPAException;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.proto.ContractNetInitiator;
import java.util.*;

public class EnhancedEnergyManager extends Agent {
    private Map<String, DeviceInfo> devices = new HashMap<>();
    private double totalConsumption = 0;
    private double powerLimit = 800;
    private String mode = "NORMAL";
    private List<String> logs = new ArrayList<>();

    private static class DeviceInfo {
        String name;
        String type;
        double lastPower = 0.0;
        long lastUpdate;
        int priority;

        DeviceInfo(String name, String type) {
            this.name = name;
            this.type = type;
            this.priority = type.equals("light-controller") ? 2 : 1;
            this.lastUpdate = System.currentTimeMillis();
        }
    }

    protected void setup() {
        System.out.println("⚡ EnergyManager запущен");

        registerWithDF();

        addBehaviour(new DeviceDiscoveryBehaviour());
        addBehaviour(new PowerReportHandler());
        addBehaviour(new PowerMonitorBehaviour());
        addBehaviour(new CommandHandlerBehaviour());
        addBehaviour(new LoggingBehaviour());

        addBehaviour(new OneShotBehaviour() {
            public void action() {
                log("Система управления энергией инициализирована");
                log("Лимит мощности: " + powerLimit + "W");
            }
        });
    }

    private void registerWithDF() {
        try {
            DFAgentDescription dfd = new DFAgentDescription();
            dfd.setName(getAID());

            ServiceDescription sd = new ServiceDescription();
            sd.setType("energy-manager");
            sd.setName("smart-energy");

            dfd.addServices(sd);
            DFService.register(this, dfd);

        } catch (FIPAException e) {
            e.printStackTrace();
        }
    }

    private class DeviceDiscoveryBehaviour extends TickerBehaviour {
        public DeviceDiscoveryBehaviour() {
            super(EnhancedEnergyManager.this, 10000);
        }

        protected void onTick() {
            discoverDevices();
        }

        private void discoverDevices() {
            try {
                DFAgentDescription template = new DFAgentDescription();
                ServiceDescription sd = new ServiceDescription();
                sd.setType("light-controller");
                template.addServices(sd);

                DFAgentDescription[] results = DFService.search(myAgent, template);

                for (DFAgentDescription result : results) {
                    String agentName = result.getName().getLocalName();

                    if (!devices.containsKey(agentName)) {
                        DeviceInfo info = new DeviceInfo(agentName, "light-controller");
                        devices.put(agentName, info);

                        log("Обнаружено устройство: " + agentName);
                    }
                }

                if (!devices.isEmpty()) {
                    log("Всего устройств: " + devices.size());
                }

            } catch (FIPAException e) {
                e.printStackTrace();
            }
        }
    }

    private class PowerReportHandler extends CyclicBehaviour {
        private MessageTemplate template = MessageTemplate.or(
                MessageTemplate.MatchPerformative(ACLMessage.INFORM),
                MessageTemplate.MatchPerformative(ACLMessage.REQUEST)
        );

        public void action() {
            ACLMessage msg = myAgent.receive(template);
            if (msg != null) {
                handleMessage(msg);
            } else {
                block();
            }
        }

        private void handleMessage(ACLMessage msg) {
            String content = msg.getContent();

            if (content.startsWith("power-report:")) {
                // Формат: power-report:LightController-LivingRoom:324.0
                String[] parts = content.split(":");
                if (parts.length >= 3) {
                    String deviceName = parts[1];
                    try {
                        double power = Double.parseDouble(parts[2]);

                        DeviceInfo info = devices.get(deviceName);
                        if (info != null) {
                            info.lastPower = power;
                            info.lastUpdate = System.currentTimeMillis();
                            log("Потребление от " + deviceName + ": " + power + "W");
                        }
                    } catch (NumberFormatException e) {
                        log("Ошибка парсинга power-report: " + content);
                    }
                }
            }
        }
    }

    private class PowerMonitorBehaviour extends TickerBehaviour {
        public PowerMonitorBehaviour() {
            super(EnhancedEnergyManager.this, 3000);
        }

        protected void onTick() {
            updateTotalConsumption();

            if (totalConsumption > powerLimit * 0.8 && !mode.equals("CRITICAL")) {
                mode = "CRITICAL";
                log("КРИТИЧЕСКИЙ РЕЖИМ! Потребление: " + totalConsumption + "W");
                initiatePowerReduction(40);
            } else if (totalConsumption > powerLimit * 0.6 && mode.equals("NORMAL")) {
                mode = "SAVING";
                log("Режим экономии. Потребление: " + totalConsumption + "W");
                initiatePowerReduction(20);
            }
        }

        private void updateTotalConsumption() {
            double sum = 0;
            for (DeviceInfo info : devices.values()) {
                sum += info.lastPower;
            }
            totalConsumption = sum;
        }
    }

    private class CommandHandlerBehaviour extends CyclicBehaviour {
        private MessageTemplate template = MessageTemplate.MatchPerformative(ACLMessage.REQUEST);

        public void action() {
            ACLMessage msg = myAgent.receive(template);
            if (msg != null) {
                handleCommand(msg);
            } else {
                block();
            }
        }

        private void handleCommand(ACLMessage msg) {
            String content = msg.getContent();

            if (content.startsWith("initiate-contract-net:")) {
                try {
                    double percent = Double.parseDouble(content.substring(22));
                    log("Команда: запуск Contract Net на " + percent + "%");
                    initiatePowerReduction(percent);

                    ACLMessage reply = msg.createReply();
                    reply.setPerformative(ACLMessage.CONFIRM);
                    reply.setContent("Contract Net запущен на " + percent + "%");
                    send(reply);

                } catch (NumberFormatException e) {
                    log("Ошибка парсинга: " + content);
                }
            } else if (content.equals("emergency-reduction")) {
                log("Команда: экстренное сокращение");
                initiatePowerReduction(50);
            } else if (content.equals("get-status")) {
                ACLMessage reply = msg.createReply();
                reply.setPerformative(ACLMessage.INFORM);
                reply.setContent(getStatus());
                send(reply);
            }
        }
    }

    private void initiatePowerReduction(double percent) {
        log("Запуск Contract Net для сокращения на " + percent + "%");
        log("Текущее потребление: " + totalConsumption + "W");
        log("Требуемая экономия: " + (totalConsumption * percent / 100.0) + "W");

        ACLMessage cfp = new ACLMessage(ACLMessage.CFP);
        cfp.setProtocol("fipa-contract-net");
        cfp.setContent("reduce-power:" + percent);
        cfp.setReplyByDate(new Date(System.currentTimeMillis() + 30000));

        int receiverCount = 0;
        for (DeviceInfo info : devices.values()) {
            cfp.addReceiver(new AID(info.name, AID.ISLOCALNAME));
            receiverCount++;
        }

        log("CFP отправлен " + receiverCount + " устройствам");

        if (receiverCount > 0 && totalConsumption > 0) {
            addBehaviour(new PowerReductionContractNet(cfp, percent));
        } else {
            log("Нет устройств или нулевое потребление!");
        }
    }

    private class PowerReductionContractNet extends ContractNetInitiator {
        private double targetReduction;
        private List<String> acceptedProposals = new ArrayList<>();

        public PowerReductionContractNet(ACLMessage cfp, double reduction) {
            super(EnhancedEnergyManager.this, cfp);
            targetReduction = reduction;
        }

        protected void handlePropose(ACLMessage propose, Vector acceptances) {
            String device = propose.getSender().getLocalName();
            double savedPower = Double.parseDouble(propose.getContent());
            log("Предложение от " + device + ": " + savedPower + "W");
        }

        protected void handleRefuse(ACLMessage refuse) {
            log("Отказ от " + refuse.getSender().getLocalName());
        }

        protected void handleAllResponses(Vector responses, Vector acceptances) {
            Map<String, Double> proposals = new HashMap<>();
            double totalSaved = 0;
            int proposalCount = 0;
            int refuseCount = 0;

            for (Object obj : responses) {
                ACLMessage msg = (ACLMessage) obj;
                if (msg.getPerformative() == ACLMessage.PROPOSE) {
                    try {
                        double saved = Double.parseDouble(msg.getContent());
                        proposals.put(msg.getSender().getLocalName(), saved);
                        totalSaved += saved;
                        proposalCount++;
                    } catch (NumberFormatException e) {}
                } else if (msg.getPerformative() == ACLMessage.REFUSE) {
                    refuseCount++;
                }
            }

            double requiredReduction = totalConsumption * targetReduction / 100.0;

            log("Результаты Contract Net:");
            log("  Получено предложений: " + proposalCount);
            log("  Получено отказов: " + refuseCount);
            log("  Требуется экономия: " + String.format("%.1f", requiredReduction) + "W");
            log("  Предложено экономии: " + String.format("%.1f", totalSaved) + "W");

            if (proposalCount > 0 && totalSaved >= requiredReduction * 0.5) {
                selectBestProposals(proposals, requiredReduction, acceptances);
                log("Contract Net успешен! Принято " + acceptedProposals.size() + " предложений");
            } else {
                log("Недостаточно предложений");
            }
        }

        private void selectBestProposals(Map<String, Double> proposals, double required, Vector acceptances) {
            List<Map.Entry<String, Double>> sorted = new ArrayList<>(proposals.entrySet());
            sorted.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));

            double accumulated = 0;
            for (Map.Entry<String, Double> entry : sorted) {
                if (accumulated < required) {
                    ACLMessage accept = new ACLMessage(ACLMessage.ACCEPT_PROPOSAL);
                    accept.addReceiver(new AID(entry.getKey(), AID.ISLOCALNAME));
                    accept.setContent("accepted");
                    acceptances.add(accept);
                    accumulated += entry.getValue();
                    acceptedProposals.add(entry.getKey());

                    System.out.println("Отправляю ACCEPT_PROPOSAL к " + entry.getKey() + " за экономию " + entry.getValue() + "W");

                } else {
                    ACLMessage reject = new ACLMessage(ACLMessage.REJECT_PROPOSAL);
                    reject.addReceiver(new AID(entry.getKey(), AID.ISLOCALNAME));
                    reject.setContent("rejected");
                    send(reject);

                    System.out.println("Отправляю REJECT_PROPOSAL к " + entry.getKey());
                }
            }
        }

        protected void handleInform(ACLMessage inform) {
            log("Успешное сокращение от " + inform.getSender().getLocalName());
        }

        protected void handleFailure(ACLMessage failure) {
            log("Ошибка сокращения от " + failure.getSender().getLocalName());
        }
    }

    private class LoggingBehaviour extends TickerBehaviour {
        public LoggingBehaviour() {
            super(EnhancedEnergyManager.this, 10000);
        }

        protected void onTick() {
            System.out.println("\n=== ОТЧЕТ ENERGY MANAGER ===");
            System.out.println("Режим: " + mode);
            System.out.println("Потребление: " + String.format("%.1f", totalConsumption) + "W / " + powerLimit + "W");
            System.out.println("Устройств: " + devices.size());

            if (!logs.isEmpty()) {
                System.out.println("Последние события:");
                int start = Math.max(0, logs.size() - 3);
                for (int i = start; i < logs.size(); i++) {
                    System.out.println("  " + logs.get(i));
                }
            }
            System.out.println("========================\n");
        }
    }

    private String getStatus() {
        return String.format("EnergyManager: потребление %.1fW, лимит %.0fW, режим %s, устройств %d",
                totalConsumption, powerLimit, mode, devices.size());
    }

    private void log(String message) {
        String timestamp = new java.text.SimpleDateFormat("HH:mm:ss").format(new Date());
        String logEntry = "[" + timestamp + "] " + message;
        logs.add(logEntry);
        System.out.println(logEntry);
    }

    protected void takeDown() {
        try {
            DFService.deregister(this);
        } catch (FIPAException e) {
            e.printStackTrace();
        }
        System.out.println(getLocalName() + " завершает работу");
    }
}