package smarthome;

import jade.core.Agent;
import jade.core.AID;
import jade.core.behaviours.*;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.*;
import jade.domain.FIPAException;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.proto.ContractNetResponder;
import java.util.*;

public class EnhancedLightAgent extends Agent {
    private String room;
    private List<String> controlledLights = new ArrayList<>();
    private Map<String, LightState> lightStates = new HashMap<>();
    private int roomBrightness = 0;
    private String mode = "MANUAL";
    private double lastReportedPower = 0.0;

    private class LightState {
        boolean isOn;
        int brightness;
        double power;
    }

    protected void setup() {
        Object[] args = getArguments();
        if (args != null && args.length > 0) {
            if (args[0] instanceof String[]) {
                String[] lights = (String[]) args[0];
                for (String light : lights) {
                    controlledLights.add(light);
                    lightStates.put(light, new LightState());
                }
            }
            if (args.length > 1 && args[1] instanceof String) {
                room = (String) args[1];
            }
        }

        if (room == null) room = "unknown";

        System.out.println("🎛Контроллер освещения " + getLocalName() + " создан для комнаты " + room);
        System.out.println("Управляет лампами: " + controlledLights);

        createLightAgents();
        registerWithDF();

        addBehaviour(new RoomControlBehaviour());
        addBehaviour(new ContractNetBehaviour());
        addBehaviour(new ModeBehaviour());
        addBehaviour(new PowerReportBehaviour());

        addBehaviour(new OneShotBehaviour() {
            public void action() {
                try { Thread.sleep(2000); } catch (Exception e) {}
                broadcastToLights("turn-on");
                setRoomBrightness(60);
            }
        });
    }

    private void createLightAgents() {
        for (String lightName : controlledLights) {
            try {
                jade.wrapper.AgentController lightAgent = getContainerController().createNewAgent(
                        lightName,
                        "smarthome.SimpleLightAgent",
                        new Object[]{room, lightName}
                );
                lightAgent.start();
                System.out.println("Создана лампа: " + lightName);

                try { Thread.sleep(100); } catch (Exception e) {}

            } catch (Exception e) {
                System.out.println("Ошибка создания лампы " + lightName + ": " + e.getMessage());
            }
        }
    }

    private void registerWithDF() {
        try {
            DFAgentDescription dfd = new DFAgentDescription();
            dfd.setName(getAID());

            ServiceDescription sd = new ServiceDescription();
            sd.setType("light-controller");
            sd.setName("room-lighting-" + room);
            sd.addProperties(new Property("room", room));
            sd.addProperties(new Property("lights-count", String.valueOf(controlledLights.size())));

            dfd.addServices(sd);
            DFService.register(this, dfd);

            System.out.println(getLocalName() + " зарегистрирован в DF");

        } catch (FIPAException e) {
            e.printStackTrace();
        }
    }

    private class RoomControlBehaviour extends CyclicBehaviour {
        private MessageTemplate template = MessageTemplate.MatchPerformative(ACLMessage.REQUEST);

        public void action() {
            ACLMessage msg = myAgent.receive(template);
            if (msg != null) {
                handleRoomCommand(msg);
            } else {
                block();
            }
        }

        private void handleRoomCommand(ACLMessage msg) {
            String content = msg.getContent();
            ACLMessage reply = msg.createReply();

            if (content.equals("room-on")) {
                broadcastToLights("turn-on");
                reply.setPerformative(ACLMessage.CONFIRM);
                reply.setContent("Комната " + room + " освещена");

            } else if (content.equals("room-off")) {
                broadcastToLights("turn-off");
                reply.setPerformative(ACLMessage.CONFIRM);
                reply.setContent("Комната " + room + " затемнена");

            } else if (content.startsWith("room-brightness=")) {
                int brightness = Integer.parseInt(content.substring(16));
                setRoomBrightness(brightness);
                reply.setPerformative(ACLMessage.CONFIRM);
                reply.setContent("Яркость комнаты: " + brightness + "%");

            } else if (content.equals("room-status")) {
                reply.setPerformative(ACLMessage.INFORM);
                reply.setContent(getRoomStatus());

            } else if (content.startsWith("mode=")) {
                mode = content.substring(5);
                reply.setPerformative(ACLMessage.CONFIRM);
                reply.setContent("Режим: " + mode);

            } else {
                reply.setPerformative(ACLMessage.NOT_UNDERSTOOD);
            }

            send(reply);
        }
    }

    private class ContractNetBehaviour extends CyclicBehaviour {
        private MessageTemplate template = MessageTemplate.and(
                MessageTemplate.MatchPerformative(ACLMessage.CFP),
                MessageTemplate.MatchProtocol("fipa-contract-net")
        );

        public void action() {
            ACLMessage cfp = myAgent.receive(template);
            if (cfp != null) {
                System.out.println(getLocalName() + " получил CFP: " + cfp.getContent());
                handleEnergyCFP(cfp);
            } else {
                block();
            }
        }

        private void handleEnergyCFP(ACLMessage cfp) {
            String content = cfp.getContent();

            if (content.startsWith("reduce-power:")) {
                double reductionPercent = Double.parseDouble(content.substring(13));

                double currentPower = calculateRoomPower();
                double targetPower = currentPower * (1 - reductionPercent / 100);

                if (targetPower < 10) {
                    sendRefuse(cfp, "Не могу снизить ниже минимума");
                    return;
                }

                int newBrightness = calculateNewBrightness(targetPower);
                double savedPower = currentPower - calculatePowerForBrightness(newBrightness);

                ACLMessage propose = cfp.createReply();
                propose.setPerformative(ACLMessage.PROPOSE);
                propose.setContent(String.valueOf(savedPower));
                propose.setConversationId(cfp.getConversationId());
                send(propose);

                System.out.println(getLocalName() + ": предлагаю экономию " + savedPower + "W");

                addBehaviour(new WaitForAcceptance(cfp, newBrightness, savedPower));
            }
        }

        private void sendRefuse(ACLMessage cfp, String reason) {
            ACLMessage refuse = cfp.createReply();
            refuse.setPerformative(ACLMessage.REFUSE);
            refuse.setContent(reason);
            send(refuse);
        }
    }

    private class WaitForAcceptance extends Behaviour {
        private ACLMessage cfp;
        private int newBrightness;
        private double savedPower;
        private boolean done = false;

        public WaitForAcceptance(ACLMessage cfp, int brightness, double saved) {
            this.cfp = cfp;
            this.newBrightness = brightness;
            this.savedPower = saved;
        }

        public void action() {
            MessageTemplate template = MessageTemplate.and(
                    MessageTemplate.MatchConversationId(cfp.getConversationId()),
                    MessageTemplate.or(
                            MessageTemplate.MatchPerformative(ACLMessage.ACCEPT_PROPOSAL),
                            MessageTemplate.MatchPerformative(ACLMessage.REJECT_PROPOSAL)
                    )
            );

            ACLMessage response = myAgent.receive(template);
            if (response != null) {
                if (response.getPerformative() == ACLMessage.ACCEPT_PROPOSAL) {
                    // ⬇⬇⬇ ЭТО ДОЛЖНО БЫТЬ В КОДЕ ⬇⬇⬇
                    System.out.println(getLocalName() + ": ПРИНЯТО предложение от EnergyManager!");
                    System.out.println(getLocalName() + ": Уменьшаю яркость с " + roomBrightness + "% до " + newBrightness + "%");
                    System.out.println(getLocalName() + ": Экономия: " + savedPower + "W");
                    // ⬆⬆⬆ ЭТО ДОЛЖНО БЫТЬ В КОДЕ ⬆⬆⬆

                    setRoomBrightness(newBrightness);

                    ACLMessage inform = response.createReply();
                    inform.setPerformative(ACLMessage.INFORM);
                    inform.setContent("Экономия " + savedPower + "W в комнате " + room);
                    send(inform);

                } else {
                    System.out.println(getLocalName() + ":Предложение отклонено EnergyManager");
                }
                done = true;
            } else {
                block();
            }
        }

        public boolean done() {
            return done;
        }
    }

    private class ModeBehaviour extends TickerBehaviour {
        public ModeBehaviour() {
            super(EnhancedLightAgent.this, 10000);
        }

        protected void onTick() {
            if (mode.equals("AUTO")) {
                autoAdjustLighting();
            }
        }

        private void autoAdjustLighting() {
            Calendar cal = Calendar.getInstance();
            int hour = cal.get(Calendar.HOUR_OF_DAY);

            if (hour >= 22 || hour <= 6) {
                if (roomBrightness > 30) {
                    setRoomBrightness(30);
                }
            }
        }
    }

    private class PowerReportBehaviour extends TickerBehaviour {
        public PowerReportBehaviour() {
            super(EnhancedLightAgent.this, 3000);
        }

        protected void onTick() {
            double roomPower = calculateRoomPower();

            if (roomPower != lastReportedPower) {
                ACLMessage report = new ACLMessage(ACLMessage.INFORM);
                report.addReceiver(new AID("EnergyManager", AID.ISLOCALNAME));
                report.setContent("power-report:" + getLocalName() + ":" + roomPower);
                send(report);

                lastReportedPower = roomPower;
            }
        }
    }

    private void broadcastToLights(String command) {
        for (String lightName : controlledLights) {
            ACLMessage cmd = new ACLMessage(ACLMessage.REQUEST);
            cmd.addReceiver(new AID(lightName, AID.ISLOCALNAME));
            cmd.setContent(command);
            send(cmd);
        }
    }

    private void setRoomBrightness(int brightness) {
        roomBrightness = brightness;
        broadcastToLights("brightness=" + brightness);
        System.out.println(getLocalName() + ": яркость комнаты установлена на " + brightness + "%");
    }

    private String getRoomStatus() {
        return String.format("Комната %s: %d%% яркость, %d ламп, режим %s, потребление %.1fW",
                room, roomBrightness, controlledLights.size(), mode, calculateRoomPower());
    }

    private double calculateRoomPower() {
        return controlledLights.size() * 60.0 * roomBrightness / 100.0;
    }

    private double calculatePowerForBrightness(int brightness) {
        return controlledLights.size() * 60.0 * brightness / 100.0;
    }

    private int calculateNewBrightness(double targetPower) {
        int newBrightness = (int)((targetPower / (controlledLights.size() * 60.0)) * 100);
        if (newBrightness < 10) newBrightness = 10;
        if (newBrightness > 90) newBrightness = 90;
        return newBrightness;
    }

    protected void takeDown() {
        try {
            DFService.deregister(this);
        } catch (FIPAException e) {
            e.printStackTrace();
        }
        System.out.println(getLocalName() + " завершает работу");
    }
}